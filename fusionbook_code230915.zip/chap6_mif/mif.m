% 2022-03-26 14:09 calcualte MIF parameters

close all; clear; clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% to scan
C=20;
Bf=100; % T
taudw=1e-4; % s

nn0=1e20*10.^(0:0.1:6); % scan density n0

% n0=1e20; % m^-3

Tf=10; % keV, fixed 
gamma=5/3; % fixed
sgmv=1.1e-22; % m^3/s, DT 10keV
Y=17.6*1e6*qe; % MeV -> J
kBTf=Tf*qe*1e3;

%%

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.1,0.65,0.8]);
for icase=1:4
% icase=2;
if(icase==1) % linear
    nf=nn0*C^1;
    T0=Tf/C^(gamma-1);
    B0=Bf/C^0;
    betaf=2*mu0.*nf.*kBTf./Bf.^2;
    beta0=betaf/C^(gamma);
%     tstr='(a) Linear';
    tstr='(a) ֱ��λ��';
elseif(icase==2) %  cylinder Btheta
    nf=nn0*C^2;
    T0=Tf/C^(2*(gamma-1));
    B0=Bf/C^1;
    betaf=2*mu0.*nf.*kBTf./Bf.^2;
    beta0=betaf/C^(2*gamma-2);
%     tstr='(b) Cylindrical B_{\theta}';
    tstr='(b) ��λ�� B_{\theta}';
elseif(icase==3) %  cylinder Bz
    nf=nn0*C^2;
    T0=Tf/C^(2*(gamma-1));
    B0=Bf/C^2;
    betaf=2*mu0.*nf.*kBTf./Bf.^2;
    beta0=betaf/C^(2*gamma-4);
%     tstr='(c) Cylindrical B_{z}';
    tstr='(c) ��λ�� B_{z}';
elseif(icase==4) %  spherical
    nf=nn0*C^3;
    T0=Tf/C^(3*(gamma-1));
    B0=Bf/C^2;
    betaf=2*mu0.*nf.*kBTf./Bf.^2;
    beta0=betaf/C^(3*gamma-4);
%     tstr='(d) Spherical';
    tstr='(d) ��λ��';
end

Eth=3/2*nf*kBTf;
EL=Eth.*(1+2./(3*betaf));

Efus=0.25*nf.^2*sgmv*Y*taudw;

Qfus=Efus./EL;

subplot(2,2,icase);
loglog(nn0,Qfus,nn0,betaf,nn0,beta0,nn0,B0+0.*nn0,nn0,EL/1e9,...
    nn0,1+0.*nn0,'k--','linewidth',2);
ylim([1e-2,1e4]);
grid on;
set(gca,'gridlinestyle','-','YMinorGrid','off','XMinorGrid','off');
% grid ;
if(icase==3)
legend({'Q_{fus}','\beta_f','\beta_0','B_0 [T]','E_L [J/mm^3]'},...
    'FontSize',10,'location','best','AutoUpdate','off');
legend('boxoff');
end
if(icase==1)
    text(2e20,1e3,['C=',num2str(C),10,'B_f=',num2str(Bf),'T',10,...
        '\tau_{dw}=',num2str(taudw),'s']);
end
xlabel('n_0 [m^{-3}]');
title(tstr);

end

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);
pstr=['C=',num2str(C),',Bf=',num2str(Bf),'taudw=',num2str(taudw)];
print(gcf,'-dpdf','-painters',['mif_',pstr,'.pdf']);
% print(gcf,'-dpng',['mif_',pstr,'.png']);
