#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jun  2 10:01:11 2019

@author: hsxie
"""

import numpy as np
import matplotlib.pyplot as plt

def SigmaV_D(Ti):
    alpha = 0.2935
    a_1 = -21.38
    a0 = -25.20
    a1 = -7.101e-2
    a2 = 1.938e-4
    a3 = 4.925e-6
    a4 = -3.984e-8
    return 1e-6*np.exp(a_1/Ti**alpha+a0+a1*Ti+a2*Ti**2+a3*Ti**3+a4*Ti**4)


def SigmaV(T): # Bosch1992, Table VII
    BG = 34.3827
    mrc2 = 1.124656e6
    c1 = 1.17302e-9
    c2 = 1.51361e-2
    c3 = 7.51886e-2
    c4 = 4.60643e-3
    c5 = 1.35e-2
    c6 = -1.0675e-4
    c7 = 1.366e-5
    theta = T/(1-T*(c2+T*(c4+T*c6))/(1+T*(c3+T*(c5+T*c7))))
    xi = (BG**2/(4*theta))**(1/3)
    return 1e-6*c1*theta*np.sqrt(xi/(mrc2*T**3))*np.exp(-3*xi)

n = 256
Ti = 10**np.linspace(0,2,n)

plt.loglog(Ti,SigmaV_D(Ti))
plt.loglog(Ti,SigmaV(Ti))
plt.axis([1,2e2,1e-25,2e-21])
plt.xlabel('$T_i (keV)$',fontsize=20)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.ylabel('$<\sigma V>$',fontsize=20)

plt.show()