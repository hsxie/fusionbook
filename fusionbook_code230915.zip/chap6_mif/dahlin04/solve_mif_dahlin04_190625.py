#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun  1 18:01:18 2019

@author: hsxie
Hua-sheng Xie, huashengxie@gmail.com, CCF-ENN

0d model for MIF/MTF liner driver, n(t), T(t), I(t), R(t), B(t), etc

Ref: [Dahlin2004] Jon-Erik Dahlin and Jan Scheffel, Self-Consistent Zero-
Dimensional Numerical Simulation of a Magnetized Target Fusion Configuration, 
Physica Scripta. Vol. 70, 310–316, 2004.

"""
# To check the P_rad and P_alpha terms
# To add the Q=E_fus/E_C

import numpy as np
import matplotlib.pyplot as plt

# fusion reactivity <sigma*v>_DT, T in keV
def SigmaV_D(Ti): # Taking from DengBH's FusionRate.py
    alpha = 0.2935
    a_1 = -21.38
    a0 = -25.20
    a1 = -7.101e-2
    a2 = 1.938e-4
    a3 = 4.925e-6
    a4 = -3.984e-8
    return 1e-6*np.exp(a_1/Ti**alpha+a0+a1*Ti+a2*Ti**2+a3*Ti**3+a4*Ti**4)

def SigmaV(T): # Bosch1992, Table VII
    BG = 34.3827
    mrc2 = 1.124656e6
    c1 = 1.17302e-9
    c2 = 1.51361e-2
    c3 = 7.51886e-2
    c4 = 4.60643e-3
    c5 = 1.35e-2
    c6 = -1.0675e-4
    c7 = 1.366e-5
    theta = T/(1-T*(c2+T*(c4+T*c6))/(1+T*(c3+T*(c5+T*c7))))
    xi = (BG**2/(4*theta))**(1/3)
    return 1e-6*c1*theta*np.sqrt(xi/(mrc2*T**3))*np.exp(-3*xi)

# constants
mu0=4.0e-7*np.pi # H/m
e=1.6022e-19 # C
kB=1.3807e-23 # J/K

# input
icase=2
if (icase==1):
    n0=1e23 # initial plasma density, m^-3
    T0=300 # initial plasma temperature, eV -> p=n*e*T instead of p=n*k_B*T
    d0=1e-3 # initial liner thickness, m
    R0=5e-2 # initial liner radius, m
    l0=30e-2 # initial plasma length, m
    delta=2.4 # compressional dimension
    B0=3.5 # initial magnetic field, T
    rho=2.7e3 # liner density, kg/m^3
    a=1.1*R0 # return current radius, m
    u0=480e3 # initial capacitor voltage, V
    C=0.31e-3 # bank capacitance, F
    Rc=1e-3 # total system resistance, Ohm

    Tend=5e-6 # total time, s
    nt=5000*2
    dt=Tend/nt # time step, s

else:
    n0=4.7e23 # initial plasma density, m^-3
    T0=143 # initial plasma temperature, eV -> p=n*e*T instead of p=n*k_B*T
    d0=7.1e-3 # initial liner thickness, m
    R0=17e-2 # initial liner radius, m
    l0=100e-2 # initial plasma length, m
    delta=2.8 # compressional dimension
    B0=5.2 # initial magnetic field, T
    rho=9.4e3 # liner density, kg/m^3
    a=1.3*R0 # return current radius, m
    u0=582e3 # initial capacitor voltage, V
    C=5.3e-3 # bank capacitance, F
    Rc=1.1e-3 # total system resistance, Ohm

    Tend=80e-6 # total time, s
    nt=5000*1
    dt=Tend/nt # time step, s

V0=(R0**delta) # V=R0^delta, to modify
#V0=np.pi*R0**2*l0

# set initial data
R=R0
T=T0
d=d0
l=l0
I=0.0
B=B0
n=n0
uC=u0
Rs=2/3*(3*R0**2+3*R0*d0+d0**2)/(2*R0+d0) # R^*
nH=n0
nHe=0.0
fb=0.0

# initial q1 to q5
q1=Rs # R^*
q2=0.0 # dR^*/dt, to check
q3=R0**(2*delta/3)*T0
#q4=(n0/2)*R0**delta # nH*R^delta # wrong 19-06-02 08:59
q4=nH*R0**delta # nH*R^delta
q5=u0 # u_C
q6=I/C # I/C

t=0.0
tt=0.0*np.arange(0,nt)
Bt=0.0*tt
uCt=0.0*tt
Rt=0.0*tt
Tt=0.0*tt
It=0.0*tt
dent=0.0*tt
Pradt=0.0*tt
Palphat=0.0*tt
nHet=0.0*tt
fbt=0.0*tt

PBt=0.0*tt
betat=0.0*tt
Qt=0.0*tt
Vt=0.0*tt

for it in range(0,nt):
    
    #print(t,'\t',R,'\t',T,'\t',I,'\t',uC)
    
    t=t+dt
    L=mu0*l/(2*np.pi)*np.log(a/(R+d))
    
    # 19-06-01 22:38 it seems that Prad and Palpha donot affect too much before T> keV
    # To check
    Prad=1.692e-38*n0*(nH+4*nHe)*np.sqrt(T) # radiation energy loss, T in eV
    Palpha=0.25*nH**2*SigmaV(T*1e-3)*(3.52e6*e) # alpha energy gain, to check, Ref: YangXJ 2009
    
    #q1=q1+q2*dt # seems dR/dt better than dRs/dt
    dRdt=0.5*q2*(1.0+np.sqrt(R**2+d0**2+2*R0*d0)/R) # to check, based Eqs.(1)&(5)
    R=R+dRdt*dt
    Rs=2/3*(3*R**2+3*R*d+d**2)/(2*R+d)
    q1=Rs
    
    q2=q2+(-mu0*I**2/(8*np.pi**2*rho*d*(R+d)**2)+2*n*e*T/(rho*d)+B**2/(2*mu0*rho*d))*dt
    #q2=q2+(-mu0*I**2/(2*np.pi**2*rho*d*(R+d)*(2*R+d))+2*n*e*T/(rho*d)+B**2/(2*mu0*rho*d))*dt # by DengBH
    #q3=q3+(Palpha-Prad)*R**(2*delta/3)/(3*n*e)*dt # form in Dahlin04
    q3=q3+delta*(Palpha-Prad)*R**(2*delta/3)/(3*n*e)*dt # 19-06-02 13:00 update
    q4=q4-0.25*R**delta*nH**2*SigmaV(T*1e-3)*dt
    q5=q5+q6*dt
    q6=q6+((mu0*l/(2*np.pi*L*(R+d))*dRdt-Rc/L)*q6-q5/(L*C))*dt
    
    I=q6*C
    uC=q5
    nH=q4/R**delta
    T=q3/R**(2/3*delta)
    n=0.5*(nH+n0*R0**delta/R**delta)
    nHe=n-nH
    d=-R+np.sqrt(R**2+d0**2+2*R0*d0)
    B=R0**2*B0/R**2 # B~1/R^2, due to flux conserved
    #nH=2*n-n0*R0**delta/R**delta # 2*n=2*nH+2*nHe=2*nH+(n0*R0**delta/R**delta-nH)
    fb=2*nHe/n0*(R/R0)**delta
    
    PB=B**2/(2*mu0) # magnetic pressure
    beta=(2*n*e*T)/PB # plasma beta, n_i+n_e=2n
    
    tt[it]=t
    Rt[it]=R
    Bt[it]=B
    uCt[it]=uC
    Tt[it]=T
    It[it]=I
    dent[it]=n
    Pradt[it]=Prad
    Palphat[it]=Palpha
    nHet[it]=nHe
    fbt[it]=fb
    
    Vt[it]=dRdt
    PBt[it]=PB
    betat[it]=beta
    Qt[it]=fb*n0*V0*(3.52e6*e/2)/(C*u0**2/2)

Rmin=np.min(Rt)
nmax=np.max(dent)
Tmax=np.max(Tt)
Bmax=np.max(Bt)

ttm=tt*1e6
Tendm=Tend*1e6
    
#%%   
plt.close("all")
fig=plt.figure(figsize=(7,7))

plt.subplot(311)  
plt.plot(ttm,Rt*1e2,label='R[cm]')
plt.plot(ttm,(-Rt+np.sqrt(Rt**2+d0**2+2*R0*d0))*1e3,'--',label='d[mm]')
plt.xlim([0,ttm[-1]])
#plt.xticks([])
plt.yticks(fontsize=12)
plt.ylabel('R[cm]',fontsize=15)
plt.grid(True)
plt.legend(loc='best')
plt.text(0.5*Tendm,0.5,'$R_{min}$='+str(round(Rmin*1e2,3))+'cm')

#plt.title('$R_0$='+str(R0*1e2)+'cm, $d_0$='+str(round(d0*1e3,4))+'mm, $l_0$='+\
#          str(l0*1e2)+'cm, $\delta$='+str(delta)+',\n $B_0$='+str(B0)+\
#          'T, $n_0$='+str(n0)+'$m^{-3}$, $T_0$='+str(T0/1e3)+\
#          'keV')

plt.subplot(312)
plt.semilogy(ttm,Tt/1e3,label='T[keV]')
plt.semilogy(ttm,fbt*1e2,'--',label='$f_b[\%]$')
plt.xlim([0,ttm[-1]])
#plt.xticks([])
plt.yticks(fontsize=12)
plt.ylabel('T[keV]',fontsize=15)
plt.grid(True)
plt.legend(loc='best')
plt.text(0.3*Tendm,1e1,'$T_{max}$='+'{:5.2f}'.format(Tmax/1e3)+'keV')
plt.ylim([1e-2,1e2])

#plt.title(r'$\rho$='+str(rho)+'$kg/m^3$, a='+str(round(a*1e2,4))+\
#          'cm, $u_C$='+str(u0/1e3)+'kV,\n C='+str(C*1e3)+\
#          'mF, $R_C$='+str(Rc*1e3)+'m$\Omega$')

#plt.subplot(523)  
#plt.plot(ttm,It/1e6)
#plt.xlim([0,ttm[-1]])
##plt.xticks([])
#plt.yticks(fontsize=12)
#plt.ylabel('I[MA]',fontsize=15)
#plt.grid(True)

plt.subplot(313)  
plt.semilogy(ttm,Bt,label='B[T]')
plt.semilogy(ttm,np.abs(Vt/1e3),'--',label='$v$[km/s]')
plt.xlim([0,ttm[-1]])
plt.ylim([1e-2,1e4])
#plt.xticks([])
#plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.ylabel('B[T]',fontsize=15)
plt.grid(True)
plt.legend(loc='best')
plt.text(0.5*Tendm,1e2,'$B_{max}$='+'{:5.2f}'.format(Bmax)+'T')

#plt.subplot(525)  
#plt.semilogy(ttm,dent,label='$n=n_H+n_{He}$')
#plt.semilogy(ttm,nHet,'--',label='$n_{He}$')
#plt.xlim([0,ttm[-1]])
##plt.xticks([])
##plt.xticks(fontsize=12)
#plt.yticks(fontsize=12)
#plt.ylabel('n[$m^{-3}$]',fontsize=15)
#plt.grid(True)
#plt.legend(loc='best')
#plt.text(0.4*Tendm,1e22,'$n_{max}$='+'{:5.2e}'.format(nmax)+'$m^{-3}$')
#plt.ylim([1e17,1e28])
#
#plt.subplot(526)  
#plt.plot(ttm,uCt/1e6)
#plt.xlim([0,ttm[-1]])
#plt.yticks(fontsize=12)
#plt.ylabel('$u_C$[MV]',fontsize=15)
#plt.grid(True)
#
#plt.subplot(527)  
#plt.plot(ttm,0.5*C*uCt**2/1e6)
#plt.xlim([0,ttm[-1]])
#plt.yticks(fontsize=12)
#plt.ylabel('$E_C$[MJ]',fontsize=15)
#plt.grid(True)
#
#plt.subplot(528)  
#plt.semilogy(ttm,Pradt/1e6,label='$P_{rad}$[W]')
#plt.semilogy(ttm,Palphat/1e6,'--',label=r'$P_{\alpha}$[W]')
#plt.xlim([0,ttm[-1]])
#plt.yticks(fontsize=12)
#plt.ylabel('P[MW]',fontsize=15)
#plt.grid(True)
#plt.legend(loc='best')

#plt.subplot(529)
#plt.semilogy(ttm,PBt/1e6,label='$P_B$[MPa]')
#plt.semilogy(ttm,2*dent*e*Tt/1e6,'--',label='$P$[MPa]')
#plt.xlim([0,ttm[-1]])
#plt.yticks(fontsize=12)
#plt.ylabel('$P$[MPa]',fontsize=15)
#plt.grid(True)
#plt.legend(loc='best')
#plt.xlabel('t ($\mu$s)',fontsize=15)
#plt.xticks(fontsize=12)
#
##fig1,ax1 = plt.subplots(5,2,10)
#ax1 = fig.add_subplot(5,2,10)
#plt.plot(ttm,betat,label=r'$\beta$')
#plt.xlim([0,ttm[-1]])
#plt.yticks(fontsize=12)
#plt.ylabel(r'$\beta$',fontsize=15)
#plt.grid(True)
#plt.xlabel('t ($\mu$s)',fontsize=15)
#plt.xticks(fontsize=12)
#
#ax2=ax1.twinx()
#plt.plot(ttm,Qt,'--',color='orange',label='Q')
##plt.ylabel('Q',fontsize=15)
#ax2.set_ylabel('Q', color='orange')
#for tl in ax2.get_yticklabels():
#    tl.set_color('orange')

plt.show()
    
fig.savefig('plt_dahlin04_R0='+str(R0)+'_short.pdf', dpi=100)
fig.savefig('plt_dahlin04_R0='+str(R0)+'_short.png', dpi=100)
