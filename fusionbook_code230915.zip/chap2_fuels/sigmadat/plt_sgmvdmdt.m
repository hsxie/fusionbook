% 22-03-22 12:30 Huasheng XIE, huashengxie@gmail.com
% 22-04-16 15:05 from p-B to for D-T

close all; clear; clc;

Tr=1:1.0:200.0; % keV


close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.8,0.55]);

Tdd=[0,20,50,100]; % drift velocity, keV
legstr={};
for j=1:length(Tdd)
    Td=Tdd(j);
% sgmv=fsgmvdm(Tr,Td,5);
sgmv=fsgmvdm(Tr,Td,1);

subplot(121);
plot(Tr,sgmv,'linewidth',3); hold on; %xlim([0,100]);
% xlabel('Effective temperature T_r [keV]');
% ylabel('Fusion reactivity <\sigma{}v> [m^3/s]'); 
xlabel('��Ч�¶� T_r [keV]');
ylabel('�۱䷴Ӧ�� <\sigma{}v> [m^3/s]'); 
legstr{j}=['E_d=',num2str(Td),' keV'];

subplot(122);
plot(Tr+Td,sgmv,'linewidth',3); hold on; xlim([0,200]);
% xlabel('Total energy T_r+E_d [keV]');
xlabel('������ T_r+E_d [keV]');

% legend('D-T','D-D','D-3He','p-11B Nevins00','p-11B Sikora16');
% grid on;
% ylabel('Fusion reactivity <\sigma{}v> [m^3/s]'); 
ylabel('�۱䷴Ӧ�� <\sigma{}v> [m^3/s]'); 

end
subplot(121);
legend(legstr,'location','best');
legend('boxoff');
% title('(a) D-T with velocity drift');
title('(a) D-T��Ư���ٶ�');
subplot(122);
% title('(b) xlabel in total energy');
title('(b)����Ϊ������');

sgmvb=0.*Tr;
for j=1:length(Tr)
    T0=1.0; % to check the convergence for different T0
sgmvb(j)=fsgmvdm(T0,Tr(j),1); % beam to cold target, 22-04-05 11:13
end
plot(Tr,sgmvb,'k--','linewidth',3);
% ylim([0,10e-22]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);
% print(gcf,'-dpdf','-painters','tst.pdf');
print(gcf,'-dpdf','sgmvdmdt.pdf');
% print(gcf,'-dpng','sgmvdm.png');
