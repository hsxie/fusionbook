% Hua-sheng XIE, huashengxie@gmail.com, 2022-03-16 15:55
% Fusion cross section in NRL Formulary
% For others, ref [Angulo1999]

function sigma=fsgmnrl(Ec,icase)
% 1. D + T -> He4 (3.5MeV) + n (14.1MeV)
% 2. D + D -> T  (1.01MeV) + p (3.02MeV)
% 3. D + D -> He3 (0.82MeV) + n (2.45MeV)
% 4. D + He3 -> He4 (3.6MeV) + p (14.7MeV)
% 5. T + T -> He4 + 2n + 12.1MeV
% 6. T + He3 -> 

A1=[45.95,    46.097,   47.88,   89.27,   38.39,   123.1];
A2=[5.02e4,   372,      482,     2.59e4,  448,     11250];
A3=[1.368e-2, 4.36e-4,  3.08e-4, 3.98e-3, 1.02e-3, 0];
A4=[1.076,    1.220,    1.177,   1.297,   2.09,    0];
A5=[409,      0,        0,       647,     0,       0];

% E=0.5*m1*v^2;
% Ec=0.5*mr*v^2;
% mr=m1*m2/(m1+m2);
% E=Ec*m1/mr=(m1+m2)/m2;
EctoE=[5/3,4/2,4/2,5/3,6/3,6/3];
E=EctoE(icase)*Ec;

sigma=( A5(icase) + A2(icase)./( (A4(icase)-A3(icase)*E).^2+...
    1))./( E.*(exp(A1(icase)./sqrt(E))-1) )*1e-28;



