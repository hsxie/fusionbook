% 2022-03-15 18:23 compare sigma
close all; clear; clc;


E=10.^(0:0.001:3); % keV
sigmadt=fsgmdt(E);
sigmadd1=fsgmdd1(E);
sigmadd2=fsgmdd2(E);
sigmadhe=fsgmdhe(E);

sigma1=fsgmnrl(E,1);
sigma2=fsgmnrl(E,2);
sigma3=fsgmnrl(E,3);
sigma4=fsgmnrl(E,4);
sigma5=fsgmnrl(E,5);
sigma6=fsgmnrl(E,6);

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.4,0.45]);

loglog(E,sigmadt,E,sigmadd1,E,sigmadd2,E,sigmadhe,...
    E,sigma1,'--',E,sigma2,'--',E,sigma3,'--',E,sigma4,'--',...
    'linewidth',3);
xlim([1,1000]);ylim([1e-31,1e-27]);
legend('D-T','D-D-1','D-D-2','D-He3',...
    'D-T','D-D-1','D-D-2','D-He3','location','best');
legend('boxoff');

% loglog(E,sigma1,'--',E,sigma2+sigma3,'--',E,sigma4,'--',...
%     E,sigma5,':',E,sigma6,':',...
%     'linewidth',3);
% xlim([1,1000]);ylim([1e-31,1e-27]);
% legend('D-T','D-D-1+D-D-2','D-He3','T-T','T-He3','location','best');
% legend('boxoff');

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
  'PaperSize',[screenposition(3:4)]);
% print(gcf,'-dpdf','-painters','tst.pdf');
% print(gcf,'-dpdf','fusion_cross_section.pdf');
print(gcf,'-dpng','NRL_fusion_cross_section2.png');