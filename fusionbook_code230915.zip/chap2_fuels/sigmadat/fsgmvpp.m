% Hua-sheng XIE, huashengxie@gmail.com, 2022-03-15 13:51
% calculate <sigma*v> integral, with effective temperature
% T_eff=(m1*T2+m2*T1)/(m1+m2), Mr=(m1*m2)/(m1+m2)
% Unit: T(keV), E(keV), sigma (m^2), <sigma*v> (m^3/s)
% 17:19 seems ok for T<500keV by compare with numerical integral <sigma*v>

function sgmvpp=fsgmvpp(T) % for p(p,mue)H2
%%
icase=2;
if(icase==1) % Angulo1999
%     % constants
%     kB=1.3807e-23; % J/K
%     qe=1.6022e-19; % C
%     NA=6.0221e23; % /mol
%     T9=(1e3*qe/kB)/1e9*T;
%     sgmvpp=4.08e-15*T9.^(-2/3).*exp(-3.381*T9.^(-1/3)).*(1+...
%         3.82*T9+1.51*T9.^2+0.144*T9.^3-1.14e-2*T9.^4);
%     sgmvpp=sgmvpp/NA*1e-6; % cm^3 -> m^3
    
%     T9=(1e3*qe/kB)/1e9
%     4.08e-15*T9.^(-2/3)/NA*1e-6
%     -3.381*T9.^(-1/3)
%     3.82*T9
%     1.51*T9.^2
%     0.144*T9.^3
%     -1.14e-2*T9.^4
    
    % Recalculate the  coefficients
    sgmvpp=1.32e-43*T.^(-2/3).*exp(-14.93./T.^(1/3)).*(1+...
        0.044*T+2.03e-4*T.^2+2.25e-7*T.^3-2.0672e-10*T.^4); %
else % Atzeni2009
    
    sgmvpp=1.56e-43*T.^(-2/3).*exp(-14.94./T.^(1/3)).*(1+...
        0.044*T+2.03e-4*T.^2+5e-7*T.^3); % Atzeni09
    %     sgmvpp=sgmvpp*2; % to check
end
