% Hua-sheng XIE, huashengxie@gmail.com, 2022-03-22 11:51
% calculate <sigma*v> integral for drift Maxwellian distribution, 
% with effective temperature, mass, drift velocity
% Tr=(m1*T2+m2*T1)/(m1+m2), Mr=(m1*m2)/(m1+m2), vd=|vd1-vd2|, Td=2*kB*vd^2
% Unit: T(keV), E(keV), sigma (m^2), <sigma*v> (m^3/s)
% 22-04-05 11:36 lack high energy >4.0MeV sigma data, will affect T>300keV

function sgmv=fsgmvdm(Tr,Td,icase)

% constants
% kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

E=10.^(-1:0.0005:3.6); % keV
% E=10.^(-2:0.0002:3.6); % keV
% E=10.^(-1:0.0005:3.5); % keV
if(icase==1) % D-T
    sigma=fsgmdt(E);
    Mr=(md*mt)/(md+mt);
elseif(icase==2) % D-D
    sigma=fsgmdd1(E)+fsgmdd2(E);
    Mr=(md*md)/(md+md);
elseif(icase==3) % D-3He
    sigma=fsgmdhe(E);
    Mr=(md*mhe)/(md+mhe);
elseif(icase==4) % p-11B, Nevins2000
    sigma=fsgmpb(E);
    Mr=(mp*mb)/(mp+mb);
elseif(icase==5) % p-11B, Sokora2016
    sigma=fsgmpb2(E);
    Mr=(mp*mb)/(mp+mb);
elseif(icase==6) % p-p, Angulo1999
    sigma=fsgmpp(E);
    Mr=(mp*mp)/(mp+mp);
end
% sigma(isnan())
% Mr=1;kB=1;
% kB*T->T*qe, eV to K, due to kB*(TkeV*1e3*qe/kB)=kB*T
sgmv=0.*Tr;
for j=1:length(Tr)
% sgmv(j)=sqrt(8/(pi*Mr))./sqrt((1e3*Tr(j)*qe).^3)*nansum(...
%     E(2:end).*sigma(2:end).*diff(E).*exp(-E(2:end)/Tr(j)));
if(Td<=1e-1) % vd->0
sgmv(j)=sqrt(qe*1e3*Tr(j)*8/(pi*Mr))./(Tr(j).^2)*nansum(...
    E(2:end).*sigma(2:end).*diff(E).*exp(-E(2:end)/Tr(j)));
else
sgmv(j)=sqrt(qe*1e3*2/(pi*Mr)/(Tr(j)*Td))*nansum(...
    sqrt(E(2:end)).*sigma(2:end).*diff(E).*exp(-(E(2:end)+Td)/Tr(j)...
    ).*sinh(2*sqrt(E(2:end)*Td)/Tr(j)));
end
end
