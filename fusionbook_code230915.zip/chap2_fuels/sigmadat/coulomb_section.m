% 2022-03-10 13:39, Huasheng XIE, huashengxie@gmail.com
% Coulomb vs Fusion cross section
% 22-03-17 09:34 update
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% n*kB*T=n20*1e20*1e3*Tkev*e
%%
E=10.^(0:0.001:3.0); % keV
sigmadt=fsgmdt(E);
% sigmadd=fsgmdd1(E)+fsgmdd2(E);
% sigmadhe=fsgmdhe(E);
% sigmapb=fsgmpb(E);
% sigmapb2=fsgmpb2(E);


% https://en.wikipedia.org/wiki/Coulomb_collision
% http://silas.psfc.mit.edu/introplasma/chap3.html
b0=qe^2/(4*pi*epsilon0)./(1e3*qe*E);
Eb=qe^2/(4*pi*epsilon0)./(1e3*qe*1.44e-15);
lnLambda=17;
sigmaclmb=(1*lnLambda)*pi*b0.^2; % to check, not the same as Hartwig's ppt

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.45,0.7]);

loglog(E,sigmadt,E,sigmaclmb,'linewidth',3);
ylim([1e-32,1e-24]);
% grid on;
% xlabel('Center-of-Mass Energy (E, keV)'); 
% ylabel('Cross section (\sigma, m^2)');
xlabel('����ϵ���� (E, keV)'); 
ylabel('���� (\sigma, m^2)');

% legend('D-T fusion','Coulomb Scattering','location','best');
legend('D-T�۱�','����ɢ��','location','best');
legend('boxoff');
% set(leg1,'Interpreter','latex','FontSize',10);
% % set(leg1,'TextColor',[0.2,0.0,0.8]);
% set(leg1,'FontWeight','bold');
% ylim([0,1.0e-21]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);
% print(gcf,'-dpdf','-painters','tst.pdf');
print(gcf,'-dpdf','coulomb_cross_section.pdf');
% print(gcf,'-depsc','coulomb_cross_section.eps');
% print(gcf,'-dpng','coulomb_cross_section.png');

