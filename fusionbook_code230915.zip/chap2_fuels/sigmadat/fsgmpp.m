% Hua-sheng XIE, huashengxie@gmail.com, 2022-03-15 13:36
% Ref: [1] Angulo1999
% [2] Atzeni2009
% p-p reaction

function sigmapp=fsgmpp(E)

% E=10.^(0:0.002:3.0); % keV

% p + p -> D + e^{+} + gamma + 1.44MeV
BGpp  =  22.20;

Spp=3.94e-25*(1+11.7e-3*E+75e-6*E.^2)*1e3; % MeV -> keV
sigmapp=Spp./(E.*exp(BGpp./sqrt(E)))*1e-28; % unit: b (1e-28 m^2) -> m^2

% sigmapp(E>100 | E<0.1)=NaN;
