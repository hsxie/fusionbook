% 2022-04-06 22:04 plot fE*sigma
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

E=0.1:0.1:100.0; % keV

sigmadt=fsgmdt(E);
sigmadt=sigmadt./max(sigmadt);

T=10;
fE=E.*exp(-E/T);
% fE=sqrt(E).*exp(-E/T);
fE=fE./max(fE);

intfE=2*fE.*sigmadt;
ind=find(intfE==max(intfE)); ind=ind(1);

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.6]);


plot(E,fE,E,sigmadt,E,intfE,'--','linewidth',3);
hold on;
patch(E,intfE,'r'); alpha(0.3); hold on;
plot([T,T],[0,fE(E==T)],'k--','linewidth',2); hold on;
plot([E(ind),E(ind)],[0,intfE(ind)],'k--','linewidth',2);

xlabel('E [keV]');
% ylim([1e3,1.5e6]);
% % xlim([1,500]);
% ylabel('P/Z_{eff} [W/m^{3}]');
text(1.05*T,0.5e0,['T=',num2str(T,3),'keV'],'FontSize',14);

text(1.02*E(ind),0.05e0,['E_m=',num2str(E(ind),3),'keV'],'FontSize',14);
% 
legend('f(E)\propto{}Ee^{-E/T}',...
    '\sigma(E) D-T',...
    '2\times{}f(E)\times\sigma(E)',...
    'Location','best');
legend('boxoff');

%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fEsgm.pdf');
