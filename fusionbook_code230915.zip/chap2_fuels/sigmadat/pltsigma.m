% 2020-04-15 23:44, test plot
% 22-03-15 18:33 plot cross section
close all;clear;clc;

E=10.^(0:0.001:3.5); % keV
sigmadt=fsgmdt(E);
sigmadd=fsgmdd1(E)+fsgmdd2(E);
sigmadhe=fsgmdhe(E);
sigmapb=fsgmpb(E);
sigmapb2=fsgmpb2(E);

sigmapp=fsgmpp(E);


% Teff=10.^(0:0.01:3.0); % keV
Teff=1:1.0:500.0; % keV
sgmv1=fsgmv(Teff,1);
sgmv2=fsgmv(Teff,2);
sgmv3=fsgmv(Teff,3);
sgmv4=fsgmv(Teff,4);
sgmv5=fsgmv(Teff,5);
sgmv6=fsgmv(Teff,6);

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.85,0.55]);

subplot(121);
loglog(E,sigmadt,E,sigmadd,E,sigmadhe,E,sigmapb,E,sigmapb2,'--',...
    E,sigmapp*1e25,':','linewidth',3);
% semilogy(E,sigmadt,E,sigmadd,E,sigmadhe,E,sigmapb,E,sigmapb2,'--','linewidth',3);
% semilogy(E,sigmapb,E,sigmapb2,'linewidth',2);
% plot(E,sigmapb,E,sigmapb2,'linewidth',2);
ylim([1e-33,1e-27]);
xlim([1,3000]);
% xlabel('Center-of-Mass Energy (E, keV)');
% ylabel('Fusion cross section (\sigma, m^2)');
xlabel('����ϵ���� (E, keV)');
ylabel('�۱䷴Ӧ���� (\sigma, m^2)');
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');

% text(210,3e-32,['Data from:',10,'Bosch & Hale, 1992',10,...
%     'Nevins & Swain, 2000',10,'Sikora & Weller, 2016',10,...
%     'Angulo et al, 1999'],'FontSize',10);
text(210,3e-32,['������Դ:',10,'Bosch & Hale, 1992',10,...
    'Nevins & Swain, 2000',10,'Sikora & Weller, 2016',10,...
    'Angulo et al, 1999'],'FontSize',10);

subplot(122);
plot(Teff,sgmv1,Teff,sgmv2,Teff,sgmv3,Teff,sgmv4,Teff,sgmv5,'--',...
    Teff,sgmv6*1e25,':','linewidth',3); hold on;
% loglog(Teff,fsgmvdt(Teff,0),':',Teff,fsgmvdd1(Teff,0)+fsgmvdd2(Teff,0),':',...
%     Teff,fsgmvdhe(Teff,0),':','linewidth',3);
ylim([1e-27,1e-21]);
% semilogx(Teff,sgmv1,Teff,sgmv2,Teff,sgmv3,Teff,sgmv4,Teff,sgmv5,'--',...
%     'linewidth',3); hold on;
% plot(Teff,fsgmvpp(Teff)*1e20,'r:',Teff,sgmv6*1e20,'k:','linewidth',3); hold on;
% plot(Teff,fsgmvdt(Teff),':',Teff,fsgmvdd1(Teff)+fsgmvdd2(Teff),':',Teff,fsgmvdhe(Teff),':','linewidth',3);
% plot(Teff,mol*sgmv1,Teff,mol*sgmv2,Teff,mol*sgmv3,Teff,mol*sgmv4,Teff,mol*sgmv5,'--','linewidth',3); hold on;
mol=1;
% plot(Teff,mol*fsgmvdt(Teff,0),Teff,mol*(fsgmvdd1(Teff,0)+fsgmvdd2(Teff,0)),...
%     Teff,mol*fsgmvdhe(Teff,0),Teff,mol*sgmv4,Teff,mol*sgmv5,'--','linewidth',3); hold on;
% ylim([0,1e-21]);
% xlim([1,10]);

% fitting in Costley15
% sigmav=@(T)10.^(-15.056179-1.7032425*(log10(T)-1.72789407).^2); % fusion reactivity, 1e-16 cm^3/s
% T=5:1:60; % keV
% plot(T,1e-6*sigmav(T),'r--','linewidth',3);

% legend('D-T','D-D','D-3He','p-11B Nevins00','p-11B Sikora16');
% plot(Teff,sgmv4,Teff,sgmv5,'linewidth',2);

% xlabel('Effective temperature T_{eff} (keV)');
% ylabel('Fusion reactivity <\sigma{}v> (m^3/s)');
xlabel('��Ч�¶� T_{eff} (keV)');
ylabel('�۱䷴Ӧ�� <\sigma{}v> (m^3/s)');
grid on;
set(gca,'YMinorGrid','off','XMinorGrid','off');
leg1=legend('${\rm D+T} \to {\rm n+{}^4He +17.59MeV}$',...
    ['${\rm D+D} \to {\rm n+{}^3He +3.27MeV}$',10,...
    '${\rm D+D }\to {\rm p+T +4.04MeV}$'],...
    '${\rm D+{}^3He} \to {\rm p+{}^4He +18.35MeV}$',...
    '${\rm p+{}^{11}B} \to {\rm 3{}^4He +8.68MeV}$, Nevins00',...
    '${\rm p+{}^{11}B} \to {\rm 3{}^4He +8.68MeV}$, Sikora16',...
    '${\rm p+p} \to {\rm D + e^{+} + \nu +1.44MeV}$, Angulo99$\times10^{25}$',...
    'Location','best');
%     '${\rm ^3He+{}^3He} \to {\rm {}^4He +2p+12.86MeV}$',...
legend('boxoff');
set(leg1,'Interpreter','latex','FontSize',10);
% set(leg1,'TextColor',[0.2,0.0,0.8]);
set(leg1,'FontWeight','bold');
% ylim([0,1.0e-21]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
% print(gcf,'-dpdf','-painters','tst.pdf');
print(gcf,'-dpdf','fusion_cross_section.pdf');
% print(gcf,'-dpng','fusion_cross_section.png');