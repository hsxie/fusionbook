% Hua-sheng XIE, huashengxie@gmail.com, 2020-04-16 20:41
% calculate <sigma*v> integral, with effective temperature
% T_eff=(m1*T2+m2*T1)/(m1+m2), Mr=(m1*m2)/(m1+m2)
% Unit: T(keV), E(keV), sigma (m^2), <sigma*v> (m^3/s)
% 22-03-15 17:26 For >100keV, use numerical integral fsgmv().

% Bosch1992
function sgmvdd2=fsgmvdd2(T,jnan) % for D(d,n)He3

if(nargin==1)
   jnan=1; 
end

BG=31.3970; %sqrt(keV)
Mrc2=937814; %keV
C=[5.43360E-12  5.85778E-3  7.68222E-3  0.0         -2.96400E-6 0.0          0.0];
theta=T./(1-T.*(C(2)+T.*(C(4)+T.*C(6)))./(1+T.*(C(3)+T.*(C(5)+T.*C(7)))));
xi=(BG^2./(4*theta)).^(1/3);
sgmvdd2=C(1).*theta.*sqrt(xi./(Mrc2.*T.^3)).*exp(-3*xi)*1e-6; % m^3/s
if(jnan==1)
    sgmvdd2(T>100 & T<0.2)=NaN;
end

% #channel      B_G[sqrt(keV)]    m_rc^2[keV]    C1           C2          C3          C4          C5          C6           C7          Tmin    Tmax    err%
% T(d,n)He4     34.3827           1124656        1.17302E-9   1.51361E-2  7.51886E-2  4.60643E-3  1.35000E-2  -1.06750E-4  1.36600E-5  0.2     100     2.5
% He3(d,p)He4   68.7508           1124572        5.51036E-10  6.41918E-3  -2.02896E-3 -1.91080E-5 1.35776E-4  0.0          0.0         0.5     190     2.5 
% D(d,p)T       31.3970           937814         5.65718E-12  3.41267E-3  1.99167E-3  0.0         1.05060E-5  0.0          0.0         0.2     100     0.35 
% D(d,n)He3     31.3970           937814         5.43360E-12  5.85778E-3  7.68222E-3  0.0         -2.96400E-6 0.0          0.0         0.2     100     0.3

