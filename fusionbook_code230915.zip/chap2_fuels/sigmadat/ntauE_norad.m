% 2020-04-20 07:51, plot n*tauE vs Q for Lawson diagram, Nevins1998 sec 5
% Ref: LiYang's Lawson Criteria notes
% 2022-03-07 07:58, rewrite to plot n*tauE vs T for D-T, D-D, D-He3, p-B11
% P_ion=Eth/tauE, without radiation loss. Q=infty
% 22-03-15 18:54  update
% 22-04-09 16:55 fixed D-D and p-p's Y and rate,
% And also change x1:x2 to max Pfus/Eth
%
close all;clear;clc;

qe=1.6022e-19; % C

% Teff=1:1.0:1000.0; % keV
Teff=10.^(-0.0:0.0005:3.0); % keV
Ti=Teff;

% icase=1;
for icase=1:5
    if(icase==1)
        Z1=1.0; Z2=1.0;
        x1=0.5; x2=(1-x1);
        Zi=x1*Z1+x2*Z2;
        
        Ydt=3.52*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        
        ntauEdt=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2*sgmvdt*Ydt);
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        Z=1; Zi=1; Zeff=1;
        x1=1; x2=1;
        
        Ydd=0.5*(3.27*1/4+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*26.73*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
        %     sgmvdd=fsgmvdd1(Teff,0)+fsgmvdd2(Teff,0);
        
        ntauEdd=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2/(1+delta12)*sgmvdd*Ydd);
        ntauEddc=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2/(1+delta12)*sgmvdd*Yddc);
        
    elseif(icase==3)
        
        x1=0.634; x2=(1-x1); Z1=1.0; Z2=2.0;
        Zi=x1*Z1+x2*Z2;
        
        Ydhe=18.35*1e6*qe; % MeV -> J
        sgmvdhe=fsgmv(Teff,3);
        %     sgmvdhe=fsgmvdhe(Teff,0);
        
        ntauEdhe=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2*sgmvdhe*Ydhe);

    elseif(icase==4)
        
        x1=0.795; x2=(1-x1); Z1=1.0; Z2=5.0;
        Zi=x1*Z1+x2*Z2;
        
        Ypb=8.68*1e6*qe; % MeV -> J
        %     sgmvpb=fsgmvpb(Teff,0);
        sgmvpb4=fsgmv(Teff,4);
        sgmvpb5=fsgmv(Teff,5);
        
        ntauEpb4=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2*sgmvpb4*Ypb);
        ntauEpb5=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2*sgmvpb5*Ypb);
        
    elseif(icase==5)
        
        delta12=1; % like particle, =1
        Z=1; Zi=1;
        x1=1; x2=1;
        
%         Ypp=1.44*1e6*qe; % MeV -> J
        Ypp=0.5*26.73*1e6*qe; % MeV -> J
        
        sgmvpp=fsgmv(Teff,6); % Angulo99
        %     sgmvpp=1.56e-43*Teff.^(-2/3).*exp(-14.94./Teff.^(1/3)).*(1+...
        %         0.044*Teff+2.03e-4*Teff.^2+5e-7*Teff.^3); % Atzeni09
        
        ntauEpp=3/2*Zi*(Zi+1.0).*(Teff*qe*1e3)./(x1*x2/(1+delta12)*sgmvpp*Ypp);
        
    end
end
%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.4,0.65,0.55]);
if(1==0)
    semilogy(Teff,ntauEdt,'linewidth',3);
    % ylim([1e-42,1e-39]);
else
    
    subplot(121);
    %     loglog(Teff,ntauEdt,Teff,ntauEdd,Teff,ntauEdhe,Teff,ntauEpb4,...
    %         Teff,ntauEpb5,'--',Teff,ntauEpp*1e-25,':',...
    %         Teff,ntauEdt1,':',Teff,ntauEdhe1,':','linewidth',3);
    loglog(Teff,ntauEdt,Teff,ntauEdd,Teff,ntauEdhe,Teff,ntauEpb4,...
        Teff,ntauEpb5,'--',Teff,ntauEddc,'-.',Teff,ntauEpp*1e-23,':','linewidth',3);
    ylim([1e18,1e24]);ylabel('n_e\tau_E [m^{-3}\cdot{}s]');
    xlim([1,1000]);
    xlabel('T_i [keV]');
    
    grid on;
    set(gca,'YMinorGrid','off','XMinorGrid','off');
    % title(['Q=\infty, without radidation, T_e/T_i=',num2str(Te_o_Ti,3)]);
%     leg1=legend(['D-T, 0.5:0.5, Y_+=',num2str(Ydt/(1e6*qe),3),'MeV'],...
%         ['D-D, Y_+=',num2str(Ydd/(1e6*qe),3),'MeV'],...
%         ['D-^3He, 0.634:0.366, Y_+=',num2str(Ydhe/(1e6*qe),3),'MeV'],...
%         ['p-^{11}B Nevins00, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
%         ['p-^{11}B Sikora16, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
%         ['Catalyzed D-D, Y_+=',num2str(Yddc/(1e6*qe),3),'MeV'],...
%         ['p-p\times10^{-23}, Y_+=',num2str(Ypp/(1e6*qe),3),'MeV'],...
%         'Location','southwest');
    leg1=legend(['D-T, 0.5:0.5, Y_+=',num2str(Ydt/(1e6*qe),3),'MeV'],...
        ['D-D, Y_+=',num2str(Ydd/(1e6*qe),3),'MeV'],...
        ['D-^3He, 0.634:0.366, Y_+=',num2str(Ydhe/(1e6*qe),3),'MeV'],...
        ['p-^{11}B Nevins00, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
        ['p-^{11}B Sikora16, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
        ['�߻�D-D, Y_+=',num2str(Yddc/(1e6*qe),3),'MeV'],...
        ['p-p\times10^{-23}, Y_+=',num2str(Ypp/(1e6*qe),3),'MeV'],...
        'Location','southwest');
    %     '${\rm ^3He+{}^3He} \to {\rm {}^4He +2p+12.86MeV}$',...
    legend('boxoff');
    set(leg1,'FontSize',9);
    % set(leg1,'Interpreter','latex','FontSize',15);
    % set(leg1,'TextColor',[0.2,0.0,0.8]);
    % set(leg1,'FontWeight','bold');
    % ylim([1e17,1.0e25]);
    
    subplot(122);
    loglog(Teff,ntauEdt.*Teff,Teff,ntauEdd.*Teff,Teff,ntauEdhe.*Teff,...
        Teff,ntauEpb4.*Teff,Teff,ntauEpb5.*Teff,'--',Teff,ntauEddc.*Teff,'-.',...
        Teff,ntauEpp.*Teff*1e-23,':','linewidth',3);
    ylim([1e20,1e25]);ylabel('n_e\tau_E{}T_i [m^{-3}\cdot{}s\cdot{}keV]');
    xlim([1,1000]);
    xlabel('T_i [keV]');
    grid on;
    set(gca,'YMinorGrid','off','XMinorGrid','off');
end

% set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters',['Lawson_ntauE_norad_pp.pdf']);
% print(gcf,'-dpng',['Lawson_ntauE_norad_pp.png']);

%%
clc;
fnt=ntauEdt;
fnt=ntauEdd;
fnt=ntauEddc;
fnt=ntauEdhe;
fnt=ntauEpb4;
fnt=ntauEpb5;
fnt=ntauEpp;
fntt=Teff.*fnt;
ind=find(fntt==min(fntt));
Teff(ind)
fntt(ind)
fnt(ind)
fntt(ind)/2.7616e+21

%% calculate the best n1:n2
if(1==0)
    close all;
    clear;clc;
    % Z1=1; Z2=1; % x=0.5; Zi=1;
%     Z1=1; Z2=2; % x=0.634; Zi=1.366;
    Z1=1; Z2=5; % x=0.795; Zi=1.820;
    x=0.01:0.001:0.99;
    
%     fx=x.*(1-x)./(x*(Z1-Z2)+Z2).^2; % max Pfus
    fx=x.*(1-x)./((x*(Z1-Z2)+Z2).*(1+(x*(Z1-Z2)+Z2))); % min n*tauE
    % fx=x.*(1-x)./(x*(Z1-Z2)+Z2)./(x*(Z1^2-Z2^2)+Z2^2); % max Pfus/PB
    
    x1=x(fx==max(fx))
    Zi=(x1*(Z1-Z2)+Z2)
    % Zeff=(x1*(Z1^2-Z2^2)+Z2^2)/(x1*(Z1-Z2)+Z2)
    % plot(x,fx);
end