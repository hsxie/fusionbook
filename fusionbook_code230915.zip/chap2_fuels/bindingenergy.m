% 2022-03-08 12:57 Hua-sheng XIE, huashengxie@gmail.com, ENN
% Binding energy per nucleon
% Most data from Ghahramany2012

close all; clear; clc;

ben.dat=[1 1 0; 
    1 2 1.11;
    1 3 2.82;
    2 3 2.57;
    2 4 7.07;
    3 6 5.33;
    3 7 5.61;
    4 9 6.46;
    5 10 6.47;
    5 11 6.92;
    6 12 7.68;
    6 13 7.46;
    7 14 7.47;
    7 15 7.70;
    8 16 7.98;
    8 17 7.75;
    9 19 7.78;
    10 21 7.97;
    11 23 8.11;
    12 25 8.22;
    12 26 8.33;
    13 27 8.33;
    14 29 8.45;
    14 30 8.52;
    15 31 8.48;
    20 43 8.60;
    24 52 8.78;
    25 55 8.765;
    26 56 8.79;
    26 57 8.77;
    29 63 8.75;
%     35 79 8.69;
    36 80 8.69;
    40 90 8.71;
%     45 103 8.58;
    47 107 8.55;
    53 127 8.45;
    55 133 8.41;
    65 159 8.19;
    74 186 7.99;
%     75 187 7.98;
    79 197 7.915;
%     80 204 7.89;
    82 208 7.88;
    92 235 7.59;
    92 238 7.57];

% ben.name={'^1H','^2H','^3H','^3He'};
%%
close all;
figure('unit','normalized','DefaultAxesFontSize',14,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.45,0.5,0.45]);
plot(ben.dat(:,2),-ben.dat(:,3),':o','linewidth',2,'markersize',6,...
    'markerfacecolor','r','markeredgecolor','k'); hold on;
% plot([56,56],[-10,0],'k--','linewidth',2);
% grid on; grid minor;
xlabel('������(A)');ylabel('�Ƚ����(MeV)');
ylim([-10,0]);

text(3,-0.0,'^{1}H','HorizontalAlignment','left','VerticalAlignment','top');
text(4,-1.11,'^{2}H','HorizontalAlignment','left','VerticalAlignment','middle');
text(5,-2.9,'^{3}H','HorizontalAlignment','left','VerticalAlignment','middle');
text(5,-2.5,'^{3}He','HorizontalAlignment','left','VerticalAlignment','middle');

text(4.5,-7.1,'^{4}He','HorizontalAlignment','center','VerticalAlignment','top');
text(5.8,-5.2,'^{6}Li','HorizontalAlignment','left','VerticalAlignment','bottom');
text(8.5,-5.6,'^{7}Li','HorizontalAlignment','left','VerticalAlignment','middle');

text(9,-6.4,'^{9}Be','HorizontalAlignment','center','VerticalAlignment','bottom');
text(12.5,-6.5,'^{10}B','HorizontalAlignment','left','VerticalAlignment','middle');
text(13.5,-7.0,'^{11}B','HorizontalAlignment','left','VerticalAlignment','middle');

text(43,-8.20,'^{43}Ca','HorizontalAlignment','center','VerticalAlignment','middle');

text(56,-8.50,'^{56}Fe','HorizontalAlignment','center','VerticalAlignment','middle');
text(80,-8.40,'^{80}Kr','HorizontalAlignment','center','VerticalAlignment','middle');
text(107,-8.20,'^{107}Ag','HorizontalAlignment','center','VerticalAlignment','middle');
text(186,-7.70,'^{186}W','HorizontalAlignment','center','VerticalAlignment','middle');
text(197,-7.60,'^{197}Au','HorizontalAlignment','center','VerticalAlignment','middle');
text(235,-7.20,'^{235}U','HorizontalAlignment','center','VerticalAlignment','middle');
text(238,-7.99,'^{238}U','HorizontalAlignment','center','VerticalAlignment','middle');


set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);

% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','bindingenergy.pdf');
print(gcf,'-dpng','bindingenergy.png');
