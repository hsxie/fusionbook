% 2022-04-16 23:25 plot black body radiation P_nu
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
c=2.99792458e8; % m/s
h=6.6261e-34; % J s

% alpha=5.67e-8;

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.3,0.65,0.54]);

ax1=axes('Position',[0.12,0.15,0.35,0.79]);

% nu=10.^(12:0.02:16);
% lmd=c./nu;

nu=2e15*(0.001:0.001:1);

TT=[5000,6000,7000];
for jT=1:length(TT)
    T=TT(jT);
    % T=6000;
    dPdnu=2*h*nu.^3/c^2./(exp(h*nu/(kB*T))-1);
    semilogy(nu,dPdnu,'linewidth',3); hold on;
    grid on;
    
end
set(gca,'YMinorGrid','off','XMinorGrid','off');
% ylim([1e-25,1e-5]);
xlabel('\nu [s^{-1}]');
ylabel('dP_{black}/d\nu [W\cdot{}m^{-2}\cdot{}s]');

ax2=axes('Position',[0.58,0.15,0.35,0.79]);
% lmd=10.^(-10:0.1:-5);
lmd=0.2e-5*(0.001:0.001:1);
for jT=1:length(TT)
    T=TT(jT);
    
    dPdlmd=2*h*(c./lmd).^3/c^2./(exp(h*(c./lmd)/(kB*T))-1)*c./lmd.^2;
    plot(lmd,dPdlmd,'linewidth',3); hold on;
    legstr{jT}=['T=',num2str(T),'K'];
    
end
legend(legstr,'Location','best');
legend('boxoff');
xlabel('\lambda [m]');
ylabel('dP_{black}/d\lambda [W\cdot{}m^{-2}\cdot{}m^{-1}]');
grid on;


set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','blacknu.pdf');