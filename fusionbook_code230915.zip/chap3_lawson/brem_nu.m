% 2022-04-08 06:42 plot Brem radiation for frequency
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
c=2.99792458e8; % m/s
h=6.6261e-34; % Js

g=1.11;
ne=1e20; Zeff=1;

% Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te)*1e6; % W/m^3, Pbrem/Zeff

% aa=1.69e-32*(1e-6)^2.*sqrt(1e3)*1e6
CB=g*32*pi/3^1.5*sqrt(2*pi)/(me^1.5*c^3*h)*(qe^2/(4*pi*epsilon0))^3*sqrt(1e3*qe)
%%

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.4,0.7,0.5]);

% TkeV=1:1:1000;
% TkeV=10;
TT=[1,10,100,200];

legstr={};

ax1=axes('Position',[0.1,0.15,0.35,0.73]);
ax2=axes('Position',[0.59,0.15,0.35,0.73]);
for jT=1:length(TT)
    TkeV=TT(jT);
    kBT=1e3*TkeV*qe;
    
    nu=10.^(16:0.1:21);
    dPdnu=g*32*pi/3^1.5*sqrt(2*pi./kBT)*(qe^2/(4*pi*epsilon0))^3/(me^1.5*c^3)*ne^2*Zeff.*exp(-h*nu/kBT);
    lmd=10.^(-16:0.1:2);
    dPdlmd=g*32*pi/3^1.5*sqrt(2*pi./kBT)*(qe^2/(4*pi*epsilon0))^3/(me^1.5*c^2)*ne^2*Zeff.*exp(-h*c./(kBT.*lmd))./lmd.^2;
    
    %     subplot(121);
    loglog(ax1,nu,dPdnu,'linewidth',3); hold(ax1,'on');
    
    %     subplot(122);
    loglog(ax2,lmd,dPdlmd,'linewidth',3); hold(ax2,'on');
    
    legstr{jT}=['T_e=',num2str(TkeV),'keV'];
end
legend(ax1,legstr,'location','best');
legend(ax1,'boxoff');
% text(20*min(nu),1e-45,['n_e=',num2str(ne,3),'m^{-3}'],'FontSize',14);
text(1e-5,1e-17,['n_e=',num2str(ne,3),'m^{-3}'],'FontSize',14);

ax1.YLim=[1e-20,1e-12];
ax1.XLim=[min(nu),max(nu)];
ax1.XLabel.String='\nu [s^{-1}]';
ax1.YLabel.String='dP_{brem}/d\nu [W\cdot{}m^{-3}\cdot{}s]';
ax1.XGrid='on';
ax1.YGrid='on';
set(ax1,'YMinorGrid','off','XMinorGrid','off');

ax2.YLim=[1e-5,1e20];
ax2.XLim=[min(lmd),max(lmd)];
ax2.XLabel.String='\lambda [m]';
ax2.YLabel.String='dP_{brem}/d\lambda [W\cdot{}m^{-3}\cdot{}m^{-1}]';
ax2.XGrid='on';
ax2.YGrid='on';
set(ax2,'YMinorGrid','off','XMinorGrid','off');
ax2.XTick=10.^(-15:5:0);

ax3=axes('Position',ax2.Position, ...    % 2nd on top of first
    'color','none', ...                % so will show through
    'XAxisLocation','top', ...         % move XAxis to top
    'XDir','reverse');                 % and flip LR
% 
ax3.YTick='';
ax3.XTick='';
ax3.XLabel.String='[keV]';
ax3.XLim=1e-3*h*c/qe*[min(1./lmd),max(1./lmd)];
ax3.XScale='log';
ax3.XTick=1e-3*h*c/qe./[1e0,1e-5,1e-10,1e-15];
ax3.XTickLabel={num2str(1e-3*h*c/qe./1e0,2),num2str(1e-3*h*c/qe./1e-5,2),...
    num2str(1e-3*h*c/qe./1e-10,2),num2str(1e-3*h*c/qe./1e-15,2)};
% box on;

ax4=axes('Position',ax1.Position, ...    % 2nd on top of first
    'color','none', ...                % so will show through
    'XAxisLocation','top');         % move XAxis to top
% 
ax4.YTick='';
ax4.XTick='';
ax4.XLabel.String='[keV]';
ax4.XLim=1e-3*h/qe*[min(nu),max(nu)];
ax4.XScale='log';
ax4.XTick=1e-3*h/qe*[1e16,1e18,1e20];
ax4.XTickLabel={num2str(1e-3*h/qe*1e16,2),num2str(1e-3*h/qe*1e18,2),...
    num2str(1e-3*h/qe*1e20,2)};

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','bremnu.pdf');

%%
% figure
% hAx(1)=axes;                                   % first axes
% hAx(2)=axes('Position',hAx(1).Position, ...    % 2nd on top of first
%     'color','none', ...                % so will show through
%     'XAxisLocation','top', ...         % move XAxis to top
%     'XDir','reverse');                 % and flip LR
% hAx(1).XLim=[0.2 1.8];                         % first axes limits
% eV=hb./hAx(1).XLim*6.242E18*1E6;               % limits of 2nd in eV from first
% hAx(2).XLim=sort(eV);                          % match the limits
% set(hAx,{'YScale'},{'log'},{'YLim'},{[1E3 1E8]});  % log y axes
%
% fneV=@(lam) hb./lam*6.242E18*1E6;        % function for wavelength-->eV
% fnWL=@(eV) hb./eV*6.242E18*1E6;          % and vice versa...convenience
% hAx(2).XLim=hAx(1).XLim;                 % use same limits to match up to
% lamAx=fnWL([0.7:0.1:0.9 1:5]);           % wavelengths for the wanted eV values
% % draw ticks at matching wavelength, label with eV value
% set(hAx(2),'XTick',sort(lamAx),'XTickLabel',fneV(lamAx))
% hAx(2).FontSize=8;                       % need a little more room
% hAx(1).YTick=[];                         % remove superfluous axis ticks
% box on                                   % add the box around the figure