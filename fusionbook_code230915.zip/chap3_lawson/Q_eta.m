% 2022-04-10 11:16 plot Q_eng vs Q for different eta
close all;clear;clc;

eta=10.^(-3:0.0001:0);

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.4,0.65,0.5]);

ax1=axes('Position',[0.1,0.16,0.35,0.8]);

Qdat=[0.1,1,5,100];
legstr1={};
for jQ=1:length(Qdat)
    Qeng=Qdat(jQ);
    Q=Qeng./eta-1;
    loglog(eta,Q,'linewidth',3); hold on;
    legstr1{jQ}=['Q_{eng}=',num2str(Qeng)];
end
xlabel('\eta=\eta_{out}\cdot\eta_{in}');
ylabel('Q');
legend(legstr1,'location','southwest','AutoUpdate','off');
legend('boxoff');
plot([min(eta),max(eta)],[1,1],'k--','linewidth',2);
ylim([1e-3,1e5]);

ax2=axes('Position',[0.6,0.16,0.35,0.8]);

Qdat2=[0.1,1,5,100];
legstr2={};
for jQ=1:length(Qdat2)
    Q=Qdat2(jQ);
    Qeng=(Q+1).*eta;
    loglog(eta,Qeng,'linewidth',3); hold on;
    legstr2{jQ}=['Q=',num2str(Q)];
end
plot([min(eta),max(eta)],[1,1],'k--','linewidth',2);
xlabel('\eta=\eta_{out}\cdot\eta_{in}');
ylabel('Q_{eng}');
legend(legstr2,'location','best','AutoUpdate','off');
legend('boxoff');
ylim([1e-3,1e2]);


set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','Qeta.pdf');