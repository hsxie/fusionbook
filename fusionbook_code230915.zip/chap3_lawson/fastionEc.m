% 2022-04-15 20:11 fast particle heating Ec
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

xpb=0.9;
x1=xpb; x2=(1-x1); Z1=1.0; Z2=5.0;
Zi=x1*Z1+x2*Z2;
Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
m1=mp; m2=11*mp; mb=4*mp;
fion=1.0;
ni=1/Zi;
n1=x1*ni; n2=x2*ni;

Ypb=8.68*1e6*qe; % MeV -> J

Te=50:1:200; % keV


Ecp=(3*sqrt(pi)/4)^(2/3)*(x1*Z1^2)^(2/3)*(m1/me)^(1/3)*mb/m1*Te/1e3;

Ecb=(3*sqrt(pi)/4)^(2/3)*(x2*Z2^2)^(2/3)*(m2/me)^(1/3)*mb/m2*Te/1e3;

Ec=(3*sqrt(pi)/4)^(2/3)*(x1*Z1^2*me/m1+x2*Z2^2*me/m2)^(2/3)*mb/me*Te/1e3;

close all;

figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.4,0.65,0.5]);

ax1=axes('Position',[0.1,0.14,0.37,0.8]);
plot(Te,Ecp,Te,Ecb,Te,Ec,'linewidth',3);
% xlim([1,1000]);
xlabel('T_e [keV]');
ylabel(['E_c [MeV], n_p/n_i=',num2str(xpb,3)]);
legend('E_{cp}','E_{cb}','E_{c}','Location','best'); 
legend('boxoff');
grid on;

Eb=8.68/3;
Pcp=(Ecp/Eb).^(1.5);
Pcb=(Ecb/Eb).^(1.5);
Pc=(Ec/Eb).^(1.5);

ax2=axes('Position',[0.58,0.14,0.37,0.8]);
plot(Te,Pcp,Te,Pcb,Te,Pc,'linewidth',3);
xlabel('T_e [keV]');
ylabel(['P_{i}/P_e, E_b=',num2str(Eb,3),' MeV']);
legend('P_{p}/P_e','P_{b}/P_e','P_{i}/P_e','Location','best'); 
legend('boxoff');
grid on;

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fastionEc.pdf');
% print(gcf,'-dpng','-painters','fastionEc.png');
