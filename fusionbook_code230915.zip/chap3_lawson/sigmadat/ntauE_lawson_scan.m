% 2022-04-10 11:55, plot n*tauE vs Q for Lawson diagram
% 14:03 plot n*tauE vs Ti, and scan fT, Q
close all;clear;clc;

qe=1.6022e-19; % C
mec2=511; % keV

% Teff=1:1.0:1000.0; % keV
Teff=10.^(-0.0:0.0002:3.0); % keV
% Teff=10.^([-0.0:0.0001:0.3,0.3:0.00005:0.7,0.7:0.0001:3.0]); % keV
Ti=Teff;

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.65,0.85]);

for jplt=1:4
    
    Qrev=1/1.0;
    if(jplt==1)
        fT=1.0;
    elseif(jplt==2)
        fT=0.5;
    elseif(jplt==3)
        fT=0.2;
    elseif(jplt==4)
        fT=0.1;
    end

Q=1/Qrev;
Te=fT*Ti;

% Pbremrel=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*((1+0.7936*(Te./mec2)+...
%     1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff)*1e6*Zeff; % W/m^3

CB=1.69e-32*(1e-6)^2*1e6;

% icase=1;
for icase=1:4
    delta12=0;
    if(icase==1)
        Z1=1.0; Z2=1.0;
        x1=0.5; x2=(1-x1);
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        fion=0.2;
        
        Ydt=17.59*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        
        geff=((1+0.7936*(Te./mec2)+...
            1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff);
        ntauEdt=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fion)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvdt*Ydt-CB*sqrt(1e3*Te).*Zeff.*geff);
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        Z=1; Zi=1; Zeff=1;
        x1=1; x2=1;
        fion=(3.27/4+4.04)/(3.27+4.04);
        fionc=26.73/43.25;
        
        Ydd=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*43.25*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
        %     sgmvdd=fsgmvdd1(Teff,0)+fsgmvdd2(Teff,0);
        
        geff=((1+0.7936*(Te./mec2)+...
            1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff);
        ntauEdd=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fion)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvdd*Ydd-CB*sqrt(1e3*Te).*Zeff.*geff);
        ntauEddc=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fionc)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvdd*Yddc-CB*sqrt(1e3*Te).*Zeff.*geff);

    elseif(icase==3)
        
%         xdhe=0.739;
        xdhe=0.7;
        x1=xdhe; x2=(1-x1); Z1=1.0; Z2=2.0;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        fion=1.0;
        
        Ydhe=18.35*1e6*qe; % MeV -> J
        sgmvdhe=fsgmv(Teff,3);
        %     sgmvdhe=fsgmvdhe(Teff,0);
        
        geff=((1+0.7936*(Te./mec2)+...
            1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff);
        ntauEdhe=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fion)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvdhe*Ydhe-CB*sqrt(1e3*Te).*Zeff.*geff);
        
    elseif(icase==4)
        
        xpb=0.9;
%         xpb=0.918;
        x1=xpb; x2=(1-x1); Z1=1.0; Z2=5.0;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        fion=1.0;
        
        Ypb=8.68*1e6*qe; % MeV -> J
        %     sgmvpb=fsgmvpb(Teff,0);
        sgmvpb4=fsgmv(Teff,4);
        sgmvpb=fsgmv(Teff,5);
        
        geff=((1+0.7936*(Te./mec2)+...
            1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff);
        ntauEpb4=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fion)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvpb4*Ypb-CB*sqrt(1e3*Te).*Zeff.*geff);
        ntauEpb=3/2*(1./Zi+fT).*(Teff*qe*1e3)./((Qrev+fion)/(1+...
            delta12)/Zi^2.*x1*x2*sgmvpb*Ypb-CB*sqrt(1e3*Te).*Zeff.*geff);
        
    end
end
%%

subplot(2,2,jplt);
loglog(Teff,ntauEdt,Teff,ntauEdd,Teff,ntauEdhe,Teff,ntauEpb4,...
    Teff,ntauEpb,'--',Teff,ntauEddc,'-.','linewidth',3);
ylim([1e18,1e24]);ylabel('n_e\tau_E [m^{-3}\cdot{}s]');
xlim([1,1000]);
xlabel('T_i [keV]');
text(1.5e2,4.2e18,['Q=',num2str(Q,3),10,'T_e/T_i=',num2str(fT,3)],'FontSize',14);

grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
if(jplt==1)
% leg1=legend('D-T, x=0.5',...
%     'D-D',...
%     ['D-^3He, x=',num2str(xdhe,3)],...
%     ['p-^{11}B Nevins00, x=',num2str(xpb,3)],...
%     ['p-^{11}B Sikora16, x=',num2str(xpb,3)],...
%     'Catalyzed D-D',...
%     'Location','southwest');
leg1=legend('D-T, x=0.5',...
    'D-D',...
    ['D-^3He, x=',num2str(xdhe,3)],...
    ['p-^{11}B Nevins00, x=',num2str(xpb,3)],...
    ['p-^{11}B Sikora16, x=',num2str(xpb,3)],...
    '�߻�D-D',...
    'Location','southwest');
%     '${\rm ^3He+{}^3He} \to {\rm {}^4He +2p+12.86MeV}$',...
legend('boxoff');
set(leg1,'FontSize',8);
end

% text(2e2,4.2e20,['Q=',num2str(Q,3),10,'T_e/T_i=',num2str(fT,3)],'FontSize',14);

% set(gca,'LooseInset',[0,0,0,0]);
end

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters',['Lawson_ntauE_scan_Q=',num2str(Q),...
    ',fT=',num2str(fT),',xdhe=',num2str(xdhe),',xpb=',num2str(xpb),'.pdf']);
% print(gcf,'-dpng',['Lawson_ntauE.png']);

%%
% clc;
% fnt=ntauEdt;
% fnt=ntauEdd;
% fnt=ntauEddc;
% fnt=ntauEdhe;
% fnt=ntauEpb4;
% fnt=ntauEpb;
% fntt=Teff.*fnt;
% ind=find(fntt==min(fntt));
% Teff(ind)
% fntt(ind)
% fnt(ind)
% fntt(ind)/2.7616e+21

%% calculate the best n1:n2
if(1==0)
    close all;
    clear;clc;
    % Z1=1; Z2=1; % x=0.5; Zi=1;
    %     Z1=1; Z2=2; % x=0.634; Zi=1.366;
    Z1=1; Z2=5; % x=0.795; Zi=1.820;
    x=0.01:0.001:0.99;
    
    %     fx=x.*(1-x)./(x*(Z1-Z2)+Z2).^2; % max Pfus
    fx=x.*(1-x)./((x*(Z1-Z2)+Z2).*(1+(x*(Z1-Z2)+Z2))); % min n*tauE
    % fx=x.*(1-x)./(x*(Z1-Z2)+Z2)./(x*(Z1^2-Z2^2)+Z2^2); % max Pfus/PB
    
    x1=x(fx==max(fx))
    Zi=(x1*(Z1-Z2)+Z2)
    % Zeff=(x1*(Z1^2-Z2^2)+Z2^2)/(x1*(Z1-Z2)+Z2)
    % plot(x,fx);
end