% 2022-04-16 06:12 fast particle fusion
% Ref: Dawson1971 PRL
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% xpb=0.9;
% x1=xpb; x2=(1-x1); Z1=1.0; Z2=5.0;
% Zi=x1*Z1+x2*Z2;
% Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
% m1=mp; m2=11*mp; mb=4*mp;
% fion=1.0;
% ni=1/Zi;
% n1=x1*ni; n2=x2*ni;
% 
% Ydt=17.59*1e6*qe; % MeV -> J
% Ypb=8.68*1e6*qe; % MeV -> J
Ydt=17.59*1e3; % MeV -> keV
Ypb=8.68*1e3; % MeV -> keV
% 
% Te=50:1:200; % keV

m1=md; m2=mt;
Z1=1; Z2=1;
mr=m1*m2/(m1+m2);
Y=Ydt;
delta12=0;

lnLmd=17;
ne=1e20;
n2=ne/Z2;

Te=10; % keV
E10=200; % keV

nt=2500;
dt=0.001e-1;
tt=(1:nt)*dt;
E1=0.*tt; P1e=0.*tt; P12=0.*tt; dEe=0.*tt; dE2=0.*tt; 
sgmv=0.*tt; Efus=0.*tt;
E1(1)=E10;
for it=1:(nt-1)
    P1e(it)=2*sqrt(me)/(3*sqrt(2*pi)*m1*(1e3*qe*Te)^(3/2))*(ne*qe^4*Z1^2*lnLmd)/(2*pi*epsilon0^2)*E1(it);
    P12(it)=sqrt(m1)/(2^(3/2)*m2*(1e3*qe*E1(it))^(3/2))*(n2*qe^4*Z2^2*Z1^2*lnLmd)/(2*pi*epsilon0^2)*E1(it);
    E1(it+1)=E1(it)-(P1e(it)+P12(it))*dt;
    dEe(it+1)=dEe(it)+P1e(it)*dt;
    dE2(it+1)=dE2(it)+P12(it)*dt;
    if(real(E1(it+1))<0 || imag(E1(it+1))~=0)
        E1((it+1):end)=NaN;
%         break;
    else
%         sgmv(it)=fsgmdt(E1(it));
        sgmv(it+1)=fsgmnrl(mr/m1*E1(it+1),1)*sqrt(2/m1*1e3*qe*E1(it+1));
    end
    Efus(it+1)=Efus(it)+n2/(1+delta12)*sgmv(it)*dt*Y;
end


% E=0.5*m1*v^2;
% Ec=0.5*mr*v^2;
% mr=m1*m2/(m1+m2);
% E=Ec*m1/mr=(m1+m2)/m2;
%%
close all;

figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.5]);

ax1=axes('Position',[0.1,0.14,0.37,0.8]);
plot(tt,E1,tt,dEe,tt,dE2,tt,sgmv*1e23,'--',tt,Efus,':','linewidth',3);
xlabel('t [s]');
ylabel(['W_1 [keV], n_e=',num2str(ne,3),'[m^{-3}]']);
legend('E_{1} [keV]','\Delta W_{e}/n_1 [keV]','\Delta W_{2}/n_1 [keV]',...
    '\sigma{}v\times1e23','E_{fus} [keV]','Location','best'); 
legend('boxoff');
grid on;

%%


Tee=[1,5,10,50,100];
% Tee=[5];
EEEfus=[];
for jTe=1:length(Tee)
Te=Tee(jTe); % keV

EE1=5:5:500;

EEfus=0.*EE1;
for jE1=1:length(EE1)
% E10=200; % keV
E10=EE1(jE1);

nt=5000;
dt=0.005e-1*E10/200;
tt=(1:nt)*dt;
E1=0.*tt; P1e=0.*tt; P12=0.*tt; dEe=0.*tt; dE2=0.*tt; 
sgmv=0.*tt; Efus=0.*tt;
E1(1)=E10;
for it=1:(nt-1)
    P1e(it)=2*sqrt(me)/(3*sqrt(2*pi)*m1*(1e3*qe*Te)^(3/2))*(ne*qe^4*Z1^2*lnLmd)/(2*pi*epsilon0^2)*E1(it);
    P12(it)=sqrt(m1)/(2^(3/2)*m2*(1e3*qe*E1(it))^(3/2))*(n2*qe^4*Z2^2*Z1^2*lnLmd)/(2*pi*epsilon0^2)*E1(it);
    E1(it+1)=E1(it)-(P1e(it)+P12(it))*dt;
    dEe(it+1)=dEe(it)+P1e(it)*dt;
    dE2(it+1)=dE2(it)+P12(it)*dt;
    if(real(E1(it+1))<0 || imag(E1(it+1))~=0)
        E1((it+1):end)=NaN;
%         break;
    else
%         sgmv(it)=fsgmdt(E1(it));
        sgmv(it+1)=fsgmnrl(mr/m1*E1(it+1),1)*sqrt(2/m1*1e3*qe*E1(it+1));
    end
    Efus(it+1)=Efus(it)+n2/(1+delta12)*sgmv(it)*dt*Y;
end
EEfus(jE1)=max(Efus);
end
EEEfus=[EEEfus;EEfus];
end

ax2=axes('Position',[0.58,0.14,0.37,0.8]);

legstr={};
for jTe=1:length(Tee)
    Te=Tee(jTe); % keV
    plot(EE1,EEEfus(jTe,:)./EE1,'linewidth',3); hold on;
    legstr{jTe}=['T_e=',num2str(Te),'keV'];
end
xlabel('E_1 [keV]');
ylabel('F=E_{fus}/E_1');

legend(legstr,'Location','best'); 
legend('boxoff');
grid on;

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','Epfusiondt.pdf');
% print(gcf,'-dpng','-painters','Epfusion.png');