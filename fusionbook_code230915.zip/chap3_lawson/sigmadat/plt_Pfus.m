% 2022-04-05 21:30 plot fusion power density
% 22-04-09 21:41 update density n1:n2=Z2:Z1 to max Pfus 
% 22-04-18 23:10 fixed Pressure and modify with magnetic field B
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% Teff=1:1.0:500.0; % keV
Teff=10.^(-0.0:0.005:3.0); % keV

% ne=1e20; % target ion density, m^-3

Pfus=10e6; % W/m^3
beta=1.0;
for icase=1:4
    delta12=0;
    
    if(icase==1)
        
        x1=0.5; x2=1-x1;
        Z1=1.0; Z2=1.0;
        Zi=x1*Z1+x2*Z2;
%         ni=ne/Zi; n1=ni*x1; n2=ni*x2;
%         Pfus=(n1*n2*sgmvdt)/(1+delta12)*Y;
%         Pfus=ne^2*x1*(1-x1)/Zi^2*sgmvdt/(1+delta12)*Y;
%         P=1.5*kB*(ne*Te+ni*Ti); % pressure
        
        Ydt=17.59*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        nedt=sqrt(Pfus./(x1*x2/Zi^2*sgmvdt/(1+delta12)*Ydt));
        
%         Pdt=1.5*(1+1/Zi)*nedt.*Teff*1e3*qe; % to check coefficient 1.5
        Pdt=(1+1/Zi)*nedt.*Teff*1e3*qe; % 22-04-18 23:14
        Bdt=sqrt(Pdt*2*mu0/beta);
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        
        x1=1.0; x2=1.0;
        Z1=1.0; Z2=1.0;
        Zi=1.0;
        Ydd=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*43.25*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
%         nedd=sqrt(Pfus./(x1*(1-x1)/Zi^2*sgmvdd/(1+delta12)*Ydd)); % to check
%         neddc=sqrt(Pfus./(x1*(1-x1)/Zi^2*sgmvdd/(1+delta12)*Yddc));
        nedd=sqrt(Pfus./(x1*x2/Zi^2*sgmvdd/(1+delta12)*Ydd)); % to check
        neddc=sqrt(Pfus./(x1*x2/Zi^2*sgmvdd/(1+delta12)*Yddc));
        
%         Pdd=1.5*(1+1/Zi)*nedd.*Teff*1e3*qe;
%         Pddc=1.5*(1+1/Zi)*neddc.*Teff*1e3*qe;
        Pdd=(1+1/Zi)*nedd.*Teff*1e3*qe;
        Pddc=(1+1/Zi)*neddc.*Teff*1e3*qe;
        Bdd=sqrt(Pdd*2*mu0/beta);
        Bddc=sqrt(Pddc*2*mu0/beta);
        
    elseif(icase==3)
        
        Z1=1.0; Z2=2.0;
        x1=Z2/(Z1+Z2); x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Ydhe=18.35*1e6*qe; % MeV -> J
        sgmvdhe=fsgmv(Teff,3);
        
        nedhe=sqrt(Pfus./(x1*x2/Zi^2*sgmvdhe/(1+delta12)*Ydhe));
%         Pdhe=1.5*(1+1/Zi)*nedhe.*Teff*1e3*qe;
        Pdhe=(1+1/Zi)*nedhe.*Teff*1e3*qe;
        Bdhe=sqrt(Pdhe*2*mu0/beta);
    elseif(icase==4)
        
        Z1=1.0; Z2=5.0;
        x1=Z2/(Z1+Z2); x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Ypb=8.68*1e6*qe; % MeV -> J
        sgmvpb=fsgmv(Teff,5);
        nepb=sqrt(Pfus./(x1*x2/Zi^2*sgmvpb/(1+delta12)*Ypb));
%         Ppb=1.5*(1+1/Zi)*nepb.*Teff*1e3*qe;
        Ppb=(1+1/Zi)*nepb.*Teff*1e3*qe;
        Bpb=sqrt(Ppb*2*mu0/beta);
    end
end

% Pressure

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.25,0.85,0.45]);

% subplot(121);
ax1=axes('Position',[0.08,0.16,0.25,0.78]);
loglog(Teff,nedt,Teff,nedd,Teff,nedhe,...
    Teff,nepb,Teff,neddc,'--','linewidth',3); hold on;
xlabel('T [keV]');
ylim([1e19,1e23]);
xlim([1,1000]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
ylabel('n_e [m^{-3}]');
text(3e0,0.3e20,['P_{fus}=',num2str(Pfus/1e6,3),'MW/m^3',...
    10,'n_1/n_2=Z_2/Z_1'],'FontSize',14);

% Patm=1e5;
% subplot(122);
ax2=axes('Position',[0.4,0.16,0.25,0.78]);
loglog(Teff,Pdt,Teff,Pdd,Teff,Pdhe,Teff,Ppb,...
    Teff,Pddc,'--','linewidth',3); hold on;
xlabel('T [keV]');
ylabel('P [Pa]');
ylim([1e5,1e10]);
xlim([1,1000]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
% legend('D-T',...
%     'D-D',...
%     'D-^3He',...
%     'p-^{11}B',...
%     'Catalyzed D-D',...
%     'Location','northeast');
legend('D-T',...
    'D-D',...
    'D-^3He',...
    'p-^{11}B',...
    '�߻�D-D',...
    'Location','northeast');
legend('boxoff');

ax3=axes('Position',[0.71,0.16,0.25,0.78]);
semilogx(Teff,Bdt,Teff,Bdd,Teff,Bdhe,Teff,Bpb,...
    Teff,Bddc,'--','linewidth',3); hold on;
xlabel('T [keV]');
ylabel('B\cdot\beta^{1/2} [T]');
ylim([0,15]);
xlim([1,1000]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');

%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fusionpfus.pdf');
% print(gcf,'-dpng',['Lawson_ntauE_norad_Te=',num2str(Te_o_Ti,3),'pp.png']);

%%
% clc;
% ind=find(Teff==200);
%
% lmfpdt_t(ind)
% lmfpdd_d(ind)
% lmfpdhe_he(ind)
% lmfppb_b(ind)
% lmd_i(ind)
%
% taudt(ind)
% taudd(ind)
% taudhe(ind)
% taupb(ind)
% tau_i(ind)


