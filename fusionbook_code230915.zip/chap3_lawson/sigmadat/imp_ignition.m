% 2022-04-06 10:59 plot fusion ideal ignition condition
% 22-04-09 22:07 update with Te/Ti<1
% 22-04-16 21:53 calculate the impurity effect
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% impurity 
fimp=0.01;
Zimp=47;
Zeff=(1+fimp*Zimp^2)/(1+fimp*Zimp);
gimp=(1+fimp*Zimp^2)*(1+fimp*Zimp); % ne^2*Zeff

Teff=1:0.5:1000.0; % keV
Te=Teff;

ne=1e20;
mec2=511; % keV
% Zeff=1;
% Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*(Zeff*(1+0.7936*(Te./mec2)+...
%     1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2))*1e6; % W/m^3
Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te)*1e6*gimp; % W/m^3, Pbrem

Pbremrel=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*((1+0.7936*(Te./mec2)+...
    1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2)/Zeff)*1e6*gimp; % W/m^3

for icase=1:4
    delta12=0;
    
    if(icase==1)
        
        Z1=1.0; Z2=1.0;
        x1=0.5; x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        ni=ne/Zi; n1=ni*x1; n2=ni*x2;
        
%         Ydt=17.59*1e6*qe; % MeV -> J
        Ydt=3.52*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        Pfusdt=(n1*n2*sgmvdt)/(1+delta12)*Ydt;
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        
        Z=1; Zi=1; Zeff=1;
        n1=ne; n2=ne;
        
%         (3.03+1.01+2.45+0.82+14.07+3.52+14.68+3.67)

%         Ydd=0.5*(3.27*3/4+4.04)*1e6*qe; % MeV -> J
%         Yddc=0.5*(3.03+1.01/5+0*2.45+0.82+0*14.07+3.52+14.68+3.67)*1e6*qe; % MeV -> J
        Ydd=0.5*(3.27*1/4+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*26.73*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
        Pfusdd=(n1*n2*sgmvdd)/(1+delta12)*Ydd;
        Pfusddc=(n1*n2*sgmvdd)/(1+delta12)*Yddc;
    end
end

% Pressure

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.6]);

ax1=axes('Position',[0.1,0.14,0.35,0.8]);
% subplot(121);
loglog(Teff,Pfusdt,...
    Teff,Pbrem,':',Teff,Pbrem/gimp,':','linewidth',3); hold on;
xlabel('T_i [keV]');
ylim([1e3,5e6]);
% xlim([1,500]);
ylabel('P [W/m^{3}]');
% text(1.2e0,0.5e6,['n_e=',num2str(ne,3),'m^{-3}',10,'T_e=T_i',10,...
%     'p-B Z_{eff}=',num2str(Zeff,3)],'FontSize',14);

leg1=legend('D-T, P_{fus}',...
    'P_{Brem}, f_{imp}=0',...
    ['P_{Brem}, f_{imp}=',num2str(fimp),', Z_{imp}=',num2str(Zimp)],...
    'Location','southeast');
legend('boxoff');
set(leg1,'FontSize',12);

ax2=axes('Position',[0.6,0.14,0.35,0.8]);

% impurity 
% fimp=0.01;
% Zimp=47;
% Zeff=(1+fimp*Zimp^2)/(1+fimp*Zimp);
% gimp=(1+fimp*Zimp^2)*(1+fimp*Zimp); % ne^2*Zeff

% ratio = gimp
% (1+fimp*Zimp^2)*(1+fimp*Zimp)=ratio;
% (1-ratio)+x^2*Z^3+(Z^2+Z)*x

ZZ=[6,8,26,74];
legstr={};
for jZ=1:length(ZZ)
Zimp=ZZ(jZ);
ratio=Pfusdt./(Pbrem/gimp);
fimp=(-(Zimp^2+Zimp)+sqrt((Zimp^2+Zimp)^2-4*(1-ratio)*Zimp^3))/(2*Zimp^3);
fimp(fimp<=0)=NaN;
semilogy(Teff,fimp,'linewidth',3); hold on;
legstr{jZ}=['Z_{imp}=',num2str(Zimp)];
end
xlim([5,40]);
legend(legstr,'Location','best');
legend('boxoff');
xlabel('T_i [keV]');
% ylim([1e3,5e6]);
% ylabel('max f_{imp}');
ylabel('���f_{imp}');

%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fimpTi.pdf');

