% 2022-04-05 13:26 plot fusion mean free path length
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

Teff=1:1.0:1000.0; % keV
% Teff=10.^(-0.0:0.005:3.0); % keV

% vm_d=sqrt(8*1e3*Teff*qe/md); % 22-04-10 20:59 wrong, miss pi
vm_d=sqrt(8/pi*1e3*Teff*qe/md);
vm_t=sqrt(8/pi*1e3*Teff*qe/mt);
vm_he=sqrt(8/pi*1e3*Teff*qe/mhe);
vm_p=sqrt(8/pi*1e3*Teff*qe/mp);
vm_b=sqrt(8/pi*1e3*Teff*qe/mb);

n2=1e20; % target ion density, m^-3

for icase=1:4
    delta12=0;
    if(icase==1)
        sgmvdt=fsgmv(Teff,1);
        
        taudt=(1+delta12)./(n2*sgmvdt);
        
        lmfpdt_d=(1+delta12)*vm_d./(n2*sgmvdt);
        lmfpdt_t=(1+delta12)*vm_t./(n2*sgmvdt);
    elseif(icase==2)
        delta12=1; % like particle, =1
        
        sgmvdd=fsgmv(Teff,2);
        
        taudd=(1+delta12)./(n2*sgmvdd);
        
        lmfpdd_d=(1+delta12)*vm_d./(n2*sgmvdd);
    elseif(icase==3)
        sgmvdhe=fsgmv(Teff,3);
        
        taudhe=(1+delta12)./(n2*sgmvdhe);
        
        lmfpdhe_d=(1+delta12)*vm_d./(n2*sgmvdhe);
        lmfpdhe_he=(1+delta12)*vm_he./(n2*sgmvdhe);
    elseif(icase==4)
        sgmvpb=fsgmv(Teff,5);
        
        taupb=(1+delta12)./(n2*sgmvpb);
        
        lmfppb_p=(1+delta12)*vm_p./(n2*sgmvpb);
        lmfppb_b=(1+delta12)*vm_b./(n2*sgmvpb);
    end
end

lmd_i=8.5e21*Teff.^2/n2; % Wesson sec14.8
tau_i=6.6e17*Teff.^(1.5)/(17*n2); % ion collisions

% tau_e=1./(2.91e-6*n2*1e-6*17*(1e3*Teff).^(-1.5));
% tau_i=1./(4.80e-8*n2*1e-6*17*(1e3*Teff).^(-1.5));

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.5]);

% subplot(121);
ax1=axes('Position',[0.1,0.14,0.35,0.8]);
loglog(Teff,lmfpdt_t,Teff,lmfpdd_d,Teff,lmfpdhe_he,...
    Teff,lmfppb_b,Teff,lmd_i,'--','linewidth',3); hold on;
xlabel('T [keV]');
ylim([1e0,1e15]);
% xlim([1,500]);
ylabel('\lambda_m [m]\cdot n_2 [10^{20}m^{-3}]');
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
% text(3e0,2e1,['Target density n_2=',num2str(n2,3),'m^{-3}'],'FontSize',14);
% leg1=legend('D-T for T',...
%     'D-D for D',...
%     'D-^3He for ^3He',...
%     'p-^{11}B for ^{11}B',...
%     ['Coulomb ion',10,'collision'],...
%     'Location','best');
leg1=legend('D-T��T',...
    'D-D��D',...
    'D-^3He��^3He',...
    'p-^{11}B��^{11}B',...
    ['����������ײ'],...
    'Location','best');
legend('boxoff');
set(leg1,'fontsize',13);


% subplot(122);
ax2=axes('Position',[0.6,0.14,0.35,0.8]);
loglog(Teff,taudt,Teff,taudd,Teff,taudhe,Teff,taupb,...
    Teff,tau_i,'--','linewidth',3); hold on;
xlabel('T [keV]');
ylabel('\tau_m [s]\cdot n_2 [10^{20}m^{-3}]');
% ylim([0.99e-5,1e10]);
ylim([0.99e-3,1e5]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
% xlim([1,500]);
%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fusionmfp.pdf');
% print(gcf,'-dpng',['Lawson_ntauE_norad_Te=',num2str(Te_o_Ti,3),'pp.png']);

%%
clc;
ind=find(Teff==10);

lmfpdt_t(ind)
lmfpdd_d(ind)
lmfpdhe_he(ind)
lmfppb_b(ind)
lmd_i(ind)

taudt(ind)
taudd(ind)
taudhe(ind)
taupb(ind)
tau_i(ind)


