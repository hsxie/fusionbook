% 2022-04-12 16:58 calculate hot ion mode Te vs Ti
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% Ti=300; % keV
% kBTe=TekeV*1e3*qe

% xpb=0.9;
xpb=0.918;
x1=xpb; x2=(1-x1); Z1=1.0; Z2=5.0;
m1=mp; m2=mb;
Zi=x1*Z1+x2*Z2;
Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
fion=1.0;
% n1=ne/Zi*x1; n2=ne/Zi*x2;

Ypb=8.68*1e6*qe; % MeV -> J
delta12=0;

lnLmd=17;

ceff=3*(2*pi)^(1.5)*epsilon0^2*sqrt(me)/qe^4*(1e-3/qe)^(-1.5);

% taue=ceff*Te.^(1.5)/(ni*Zi^2*lnLmd);
% tauei=mi/(2*me)*taue;
%
% tau1e=m1/(2*me)*ceff*Te.^(1.5)/(n1*Z1^2*lnLmd);
% tau2e=m2/(2*me)*ceff*Te.^(1.5)/(n2*Z2^2*lnLmd);


% Pfuspb=(n1*n2*sgmvpb)/(1+delta12)*Ypb/Zeff;
% 1.5*kB*(Ti-Te)*(n1/tau1e+n2/tau2e)=fion*Pfus;
% fTe=@(Te)1.5*1e3*qe*(Ti-Te)*(n1/tau1e+n2/tau2e)-fion*(n1*n2*sgmvpb)/(1+delta12)*Ypb/Zeff;
% n1=ne/Zi*x1; n2=ne/Zi*x2;


% Te=100:1:300;
Tii=50:1:300;
Tee=0.*Tii;
Titake=300;
for jT=1:length(Tii)
    Ti=Tii(jT);
    
    sgmvpb=fsgmv(Ti,5);
%     fTe=@(Te)1.5*1e3*qe*((x1*Z1)^2/m1+...
%         (x2*Z2)^2/m2)/(1/(2*me)*ceff/lnLmd)*(Ti-Te).*Te.^(-1.5)-...
%         fion*(x1*x2*sgmvpb)/(1+delta12)*Ypb/Zeff;
    fTe=@(Te)1.5*1e3*qe*((x1*Z1)^2/m1+...
        (x2*Z2)^2/m2)/(1/(2*me)*ceff/lnLmd)*(Ti-Te).*Te.^(-1.5)./...
        (fion*(x1*x2*sgmvpb)/(1+delta12)*Ypb/Zeff)-1; % 22-04-23 to check Zeff
    options=optimoptions('fsolve','Display','off');
    Te=fsolve(fTe,0.8*Ti,options);
    Tee(jT)=Te;
    
    if(Ti==Titake)
        xx=1:1:300;
        yy=fTe(xx);
        Tetake=Te;
    end
end

%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.5]);

ax1=axes('Position',[0.1,0.14,0.37,0.8]);
plot(Tii,Tee,Tii,Tii,'-','linewidth',3);
xlabel('T_i [keV]');
ylabel('T_e [keV]');
grid on;
text(200,50,['x_{p}=',num2str(xpb,3)],'FontSize',14);
leg1=legend('T_e',...
    'T_i',...
    'Location','best');
legend('boxoff');
set(leg1,'fontsize',13);

ax2=axes('Position',[0.58,0.14,0.37,0.8]);
plot(xx,yy+1,Tetake,1,'rx','linewidth',3);
% ylim([-2,5]);
ylim([0,5]);
xlabel('T_e [keV]');
ylabel(['P_{ie}/P_{fus} [T_i=',num2str(Titake),'keV]']);
grid on;

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','Tehotion.pdf');
