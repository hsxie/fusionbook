% 2022-04-07 23:21 plot fusion black body radiation r
% 22-04-09 23:31 update n1:n2=Z2:Z1, and Ypp
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% Teff=1:0.2:100.0; % keV
Teff=10.^(-1:0.01:3); % keV

alpha=5.67e-8;

Pblack=alpha*(qe/kB*1e3*Teff).^4;
%%
ne=1e25;

for icase=1:5
    delta12=0;
    
    if(icase==1)
        
        Z1=1.0; Z2=1.0;
        x1=0.5; x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        ni=ne/Zi; n1=ni*x1; n2=ni*x2;
        
        Ydt=17.59*1e6*qe; % MeV -> J
%         Ydt=3.52*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        Pfusdt=(n1*n2*sgmvdt)/(1+delta12)*Ydt;
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        
        Z=1; Zi=1; Zeff=1;
        n1=ne; n2=ne;
        
%         (3.03+1.01+2.45+0.82+14.07+3.52+14.68+3.67)

        Ydd=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*(3.03+1.01+2.45+0.82+14.07+3.52+14.68+3.67)*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
        Pfusdd=(n1*n2*sgmvdd)/(1+delta12)*Ydd;
        Pfusddc=(n1*n2*sgmvdd)/(1+delta12)*Yddc;
        
    elseif(icase==3)
        
        Z1=1.0; Z2=2.0;
        x1=Z2/(Z1+Z2); x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        ni=ne/Zi; n1=ni*x1; n2=ni*x2;
        
        Ydhe=18.35*1e6*qe; % MeV -> J
        sgmvdhe=fsgmv(Teff,3);
        Pfusdhe=(n1*n2*sgmvdhe)/(1+delta12)*Ydhe;
        
    elseif(icase==4)
        
        Z1=1.0; Z2=5.0;
        x1=Z2/(Z1+Z2); x2=1-x1;
        Zi=x1*Z1+x2*Z2;
        Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
        ni=ne/Zi; n1=ni*x1; n2=ni*x2;
        
        Ypb=8.68*1e6*qe; % MeV -> J
%         sgmvpb4=fsgmv(Teff,4);
        sgmvpb=fsgmv(Teff,5);
%         Pfuspb4=(n1*n2*sgmvpb4)/(1+delta12)*Ypb;
        Pfuspb=(n1*n2*sgmvpb)/(1+delta12)*Ypb;
        
elseif(icase==5)
    
        delta12=1; % like particle, =1
        
        Z=1; Zi=1; Zeff=1;
        n1=ne; n2=ne;

%         Ypp=1.44*1e6*qe; % MeV -> J, to update
        Ypp=0.5*26.73*1e6*qe; % MeV -> J, to update
        sgmvpp=fsgmv(Teff,6);
%         sgmvpp=sgmvpp*2; % to check
        Pfuspp=(n1*n2*sgmvpp)/(1+delta12)*Ypp;
    
    end
end


%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.25,0.6,0.6]);

% subplot(121);

rdt=Pblack./Pfusdt;
rdd=Pblack./Pfusdd;
rdhe=Pblack./Pfusdhe;
rpb=Pblack./Pfuspb;
rddc=Pblack./Pfusddc;
rpp=Pblack./(Pfuspp*1e20);

xdt=Teff(rdt==min(rdt)); ydt=rdt(rdt==min(rdt));
xdd=Teff(rdd==min(rdd)); ydd=rdd(rdd==min(rdd));
xdhe=Teff(rdhe==min(rdhe)); ydhe=rdhe(rdhe==min(rdhe));
xpb=Teff(rpb==min(rpb)); ypb=rpb(rpb==min(rpb));
xddc=Teff(rddc==min(rddc)); yddc=rddc(rddc==min(rddc));
xpp=Teff(rpp==min(rpp)); ypp=rpp(rpp==min(rpp));

ax1=axes('Position',[0.1,0.14,0.84,0.8]);
loglog(Teff,rdt,Teff,rdd,Teff,rdhe,Teff,rpb,Teff,rddc,'--',...
    Teff,rpp,'-.','linewidth',3); hold on;

plot(xdt,ydt,'kx',xdd,ydd,'kx',xdhe,ydhe,'kx',xpb,ypb,'kx',...
    xddc,yddc,'kx',xpp,ypp,'kx','linewidth',3,'MarkerSize',5);
text(xdt,0.7*ydt,['(',num2str(xdt,2),', ',num2str(ydt,2),')']);
text(xdd,0.7*ydd,['(',num2str(xdd,2),', ',num2str(ydd,2),')']);
text(xdhe,0.7*ydhe,['(',num2str(xdhe,2),', ',num2str(ydhe,2),')']);
text(xpb,0.7*ypb,['(',num2str(xpb,2),', ',num2str(ypb,2),')']);
text(xddc,0.7*yddc,['(',num2str(xddc,2),', ',num2str(yddc,2),')']);
text(xpp,0.7*ypp,['(',num2str(xpp,2),', ',num2str(ypp,2),')']);

xlabel('T [keV]');
ylim([1e8,1e16]);
% xlim([1,500]);
ylabel('r_{black} [m]');
text(0.2e0,0.9e9,['n_e=',num2str(ne,3),'m^{-3}',10,...
    'n_1/n_2=Z_2/Z_1'],'FontSize',14);

% legend('D-T',...
%     'D-D',...
%     'D-^3He',...
%     'p-^{11}B',...
%     ['Catalyzed',10, 'D-D'],...
%     'p-p \times 10^{-20}',...
%     'Location','southeast');
legend('D-T',...
    'D-D',...
    'D-^3He',...
    'p-^{11}B',...
    ['�߻�D-D'],...
    'p-p \times 10^{-20}',...
    'Location','southeast');
%     'Black body radiation',...
legend('boxoff');

%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','rblack.pdf');

%%
% clc;
% Pfus=Pfusdt;
% Pfus=Pfusdd;
% Pfus=Pfusddc;
% Pfus=Pfusdhe;
% Pfus=Pfuspb;
% Pfus=Pfuspb4;
% P1=abs(Pbrem-Pfus);  P1=P1(1:floor(0.2*length(Teff)));
% P2=abs(Pbremrel-Pfus);  P2=P2(1:floor(0.99*length(Teff)));
% ind1=find(P1==min(P1));
% ind2=find(P2==min(P2));
% Teff(ind1)
% Teff(ind2)
