% 2022-04-18 15:06 P_cycl/P_brem
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
c=2.99792458e8; % m/s
h=6.6261e-34; % Js

Zeff=1;

Te=1:1:1000;

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.2,0.65,0.5]);

ax1=axes('Position',[0.1,0.16,0.35,0.78]);
betae=0.5;
ne=1e20;
Pcycl=2.50e-38*ne^2*Te.^2/betae.*(1+Te/146);
Pbrem=5.39e-37*ne^2*Te.^0.5.*(Zeff*(1+0.7936*Te/511+...
    1.874*(Te/511).^2)+3/sqrt(2)*Te/511);

Z1=1.0; Z2=1.0; x1=0.5; x2=1-x1; Zi=x1*Z1+x2*Z2;
Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
ni=ne/Zi; n1=ni*x1; n2=ni*x2; delta12=0;

%         Ydt=17.59*1e6*qe; % MeV -> J
Ydt=3.52*1e6*qe; % MeV -> J
sgmvdt=fsgmv(Te,1);
Pfusdt=(n1*n2*sgmvdt)/(1+delta12)*Ydt/Zeff;

loglog(Te,Pcycl,Te,Pbrem,Te,Pfusdt,'linewidth',3); hold on;
% semilogy(Te,Pcycl,Te,Pbrem,Te,Pfusdt,'linewidth',3); hold on;

xlim([1,1000]); ylim([1e3,1e8]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');

xlabel('T_e [keV]');
ylabel('P [W/m^{3}]');
legend(['P_{cycl}, \beta_e=',num2str(betae)],'P_{Brem}',...
    'D-T, f_{ion}\times{}P_{fus}','Location','southeast');
legend('boxoff');
text(2e0,2e7,['n_e=',num2str(ne,3),'m^{-3}',10,'Z_{eff}=',num2str(Zeff)],'FontSize',14);

ax2=axes('Position',[0.58,0.16,0.35,0.78]);
bb=[0.01,0.05,0.5];
legstr={};
for jb=1:length(bb)
    betae=bb(jb);
    Pc_o_Pb=4.64e-2*Te.^1.5/(betae*Zeff).*(1+Te/146)./(Zeff*(1+0.7936*Te/511+...
        1.874*(Te/511).^2)+3/sqrt(2)*Te/511);
    loglog(Te,Pc_o_Pb,'linewidth',3); hold on;
    legstr{jb}=['\beta_e=',num2str(betae)];
end
xlim([1,300]); ylim([1e0,1e3]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');

xlabel('T_e [keV]');
ylabel('P_{cycl}/P_{brem}');
legend(legstr,'Location','best');
legend('boxoff');

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','Pcyclbrem.pdf');
