close all; clear; clc;

dat=load('sigPB11.txt');

T=10:1:10000;

sgm1=fsgmpb(T);
sgm2=fsgmpb2(T);

% plot(T,sgm1,dat(:,1),T,sgm2,dat(:,1),dat(:,2),'--','linewidth',2);
plot(T,sgm1,T,sgm2,dat(:,1),dat(:,2),'--',dat(:,1)*11/12,dat(:,2),'--','linewidth',2);
xlim([0,10000]);
xlabel('E [keV]');
ylabel('\sigma');
legend('Nevins','Sikora','WMY','WMY, E_c=E*11/12');

