% 2022-04-05 21:30 plot fusion power density
% 22-04-09 21:41 update density n1:n2=Z2:Z1 to max Pfus
% 22-04-18 16:56 modify for only p-B
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% Teff=1:1.0:500.0; % keV
Teff=10.^(1.0:0.005:3.0); % keV

% ne=1e20; % target ion density, m^-3

close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.45,0.65,0.5]);

PP=[0.1e6,1e6,10e6];
legstr={};
for jp=1:length(PP)
% Pfus=10e6; % W/m^3
Pfus=PP(jp);

delta12=0;

Z1=1.0; Z2=5.0;
x1=Z2/(Z1+Z2); x2=1-x1;
Zi=x1*Z1+x2*Z2;
Ypb=8.68*1e6*qe; % MeV -> J
sgmvpb=fsgmv(Teff,5);
nepb=sqrt(Pfus./(x1*x2/Zi^2*sgmvpb/(1+delta12)*Ypb));
% Ppb=1.5*(1+1/Zi)*nepb.*Teff*1e3*qe;% Pressure
Ppb=(1+1/Zi)*nepb.*Teff*1e3*qe;% Pressure

beta=0.4;
B=sqrt(Ppb*2*mu0/beta);

subplot(131);
loglog(Teff,nepb,'linewidth',3); hold on;
% semilogy(Teff,nepb,'linewidth',3); hold on;
xlabel('T [keV]');
ylim([1e19,1e23]);
% xlim([1,500]);
ylabel('n_e [m^{-3}]');
% text(3e0,0.3e20,['P_{fus}=',num2str(Pfus/1e6,3),'MW/m^3',...
%     10,'n_1/n_2=Z_2/Z_1'],'FontSize',14);

% Patm=1e5;
subplot(132);
loglog(Teff,Ppb,'linewidth',3); hold on;
xlabel('T [keV]');
ylabel('P [Pa]');
ylim([1e5,1e10]);
% xlim([1,500]);

subplot(133);
semilogx(Teff,B,'linewidth',3); hold on;
xlabel('T [keV]');
ylabel(['B [T], for \beta=',num2str(beta)]);
ylim([0,25]);

legstr{jp}=['P_{fus}=',num2str(Pfus/1e6),'MW/m^3'];
end

subplot(131);
legend(legstr,...
    'Location','northeast');
legend('boxoff');

%
% % set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
    'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','fusionpfuspb.pdf');
% print(gcf,'-dpng',['Lawson_ntauE_norad_Te=',num2str(Te_o_Ti,3),'pp.png']);


