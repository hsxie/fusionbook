% 2022-03-18 20:31 Huasheng XIE,  huashengxie@gmail.com
% Ref: Wurzel, S. E. & Hsu, S. C., 2021, arXiv

close all; clear; clc;

% Year T i 0 (keV) ni0tE(m3s) 	ni0Ti0tE(keVm3s)
dat=[1969	0.3	6.80E+16	2.00E+16; % Tokamak
1971	0.5	9.30E+17	4.60E+17;
1976	1.54	2.10E+18	3.20E+18;
1978	0.9	3.00E+19	2.70E+19;
1981	0.95	5.50E+18	5.20E+18;
1984	1.5	1.00E+20	1.60E+20;
1988	0.8	9.00E+18	7.20E+18;
1995	43	1.80E+19	7.90E+20;
1997	28	1.70E+19	4.70E+20;
1997	18.1	2.00E+19	3.70E+20;
1998	16.8	3.30E+19	5.60E+20;
2014	2	4.80E+18	9.60E+18;
2016	2.5	3.00E+19	7.40E+19;
2016	8	2.80E+18	2.20E+19;
2017	2.1	4.60E+18	9.60E+18;
2025	20	3.10E+20	6.20E+21;
2035	20	3.70E+20	7.40E+21;
1998	0.2	3.10E+17	6.10E+16; % Spherical Tokamak
2006	3	1.50E+18	4.50E+18;
2009	1.2	4.00E+18	4.80E+18;
2019	1.2	1.20E+18	1.40E+18;
1980	0.545	1.60E+18	8.60E+17; % Stellarator
2002	2.27	6.60E+18	1.50E+19;
2005	0.45	1.50E+15	6.80E+14;
2008	0.47	1.10E+20	5.20E+19;
2017	3.5	1.80E+19	6.20E+19;
1957	0.09	1E+16	9E+14; % Pinch
2003	0.1	3.3E+16	3.3E+15;
2018	1.8	1.2E+17	2.2E+17;
1977	0.01	1E+15	1E+13; % RFP
1984	0.09	3.5E+16	3.2E+15;
1987	0.33	6.7E+16	2.2E+16;
2008	1	7.5E+16	7.5E+16;
2009	1.3	1.4E+17	1.9E+17;
1990	0.18	9E+15	1.6E+15; % Spheromak
2007	0.5	2.2E+17	1.1E+17;
1993	0.547	1.3E+17	7.1E+16; % FRC
2005	0.025	2.6E+14	6.5E+12;
2005	0.18	1.6E+17	2.9E+16;
2008	0.1	9.7E+14	9.7E+13;
2015	0.2	4.8E+16	9.6E+15;
2017	0.68	5.9E+15	4E+15;
2019	1	3.9E+16	3.9E+16;
1984	0.15	2E+15	3E+14; % Mirror
2007	2	6.3E+17	1.3E+18;
2018	0.45	6.6E+15	3E+15;
1994	0.9	9.20E+19	8.30E+19; % Laser ICF
2009	1.8	2.70E+20	4.90E+20;
2021	8.94	5.70E+20	5.10E+21;
2015	2.8	1.10E+20	3.00E+20]; % MagLIF

% Project
% datstr={'T-3','ST','PLT','Alcator A','TFR','Alcator C','ASDEX','TFTR',...
% 'JET','DIII-D','JT-60U','KSTAR','C-Mod','ASDEX-U','EAST','SPARC(2025)',...
% 'ITER(2035)','START','MAST','NSTX','Globus-M2','W7-A','W7-AS','HSX',...
% 'LHD','W7-X','ZETA','ZaP','FuZE','ETA-BETA I','ETA-BETA II','ZT-40M',...
% 'RFX-mod','MST','CTX','SSPX','LSX','TCS','FRX-L','TCSU','Yingguang-I',... 
% 'C-2U','C-2W','TMX-U','GOL-3','GDT','NOVA','OMEGA','NIF','MagLIF'};
datstr={'T-3','ST','PLT','Alcator A','TFR','Alcator C','ASDEX','TFTR',...
'JET','DIII-D','JT-60U','KSTAR','C-Mod','ASDEX-U','EAST','SPARC(2025Ԥ��)',...
'ITER(2035Ԥ��)','START','MAST','NSTX','Globus-M2','W7-A','W7-AS','HSX',...
'LHD','W7-X','ZETA','ZaP','FuZE','ETA-BETA I','ETA-BETA II','ZT-40M',...
'RFX-mod','MST','CTX','SSPX','LSX','TCS','FRX-L','TCSU','ӫ��һ��',... 
'C-2U','C-2W','TMX-U','GOL-3','GDT','NOVA','OMEGA','NIF(2021)','MagLIF'};
%%
close all;
figure('unit','normalized','DefaultAxesFontSize',15,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.45,0.6]);

%%
qe=1.6022e-19; % C
Te_o_Ti=1.0;
Teff=10.^(-0.0:0.0005:2.0); % keV
Ti=Teff;
Te=Te_o_Ti*Ti;
x1=0.5; x2=(1-x1); Z1=1.0; Z2=1.0;
Zi=x1*Z1+x2*Z2; Zeff=(x1*Z1^2+x2*Z2^2)/Zi;
Ydt=17.59*1e6*qe; % MeV -> J
% Ydt=3.52*1e6*qe; % MeV -> J
sgmvdt=fsgmv(Teff,1);
%     sgmvdt=fsgmvdt(Teff,0);
ntauEdt=3/2*Zi*(Zi*Te_o_Ti+1.0).*(Teff*qe*1e3)./(x1*x2*sgmvdt*Ydt);
ntauEdt(imag(ntauEdt)~=0)=NaN;

% hold on;
ax1=loglog(Ti,ntauEdt.*Ti,'-','linewidth',2);hold on;
%%
id1=17; id2=21; id3=26; id4=29; id5=34; 
id6=36; id7=43; id8=46; id9=49; id10=50;

idx=2;idy=4;
loglog(dat(1:id1,idx),dat(1:id1,idy),'d',...
    dat((id1+1):id2,idx),dat((id1+1):id2,idy),'s',...
    dat((id2+1):id3,idx),dat((id2+1):id3,idy),'p',...
    dat((id3+1):id4,idx),dat((id3+1):id4,idy),'o',...
    dat((id4+1):id5,idx),dat((id4+1):id5,idy),'<',...
    dat((id5+1):id6,idx),dat((id5+1):id6,idy),'>',...
    dat((id6+1):id7,idx),dat((id6+1):id7,idy),'v',...
    dat((id7+1):id8,idx),dat((id7+1):id8,idy),'*',...
    dat((id8+1):id9,idx),dat((id8+1):id9,idy),'^',...
    dat((id9+1):id10,idx),dat((id9+1):id10,idy),'h');
% loglog(dat(:,1),dat(:,4),'d');


xt=0.*dat(:,1)+1; yt=0.*dat(:,1)+1; jalign=0.*dat(:,1)+1;
yt(10)=0.85;
yt(11)=1.2;
yt(13)=1.3;
yt(16)=0.85;
yt(17)=1.2;
yt(26)=0.9;
yt(28)=1.25; 
jalign(31)=2;
yt(46)=0.8;
jalign(34)=4;
yt(37)=0.85;
yt(41)=0.8;
yt(1)=0.6;xt(1)=0.95;
yt(21)=1.3;
yt(45)=0.75;
jalign(7)=2;
% yt(5)=1.5;xt(5)=0.95;
jalign(5)=3;
jalign(25)=2;
jalign(18)=2;
jalign(12)=2;xt(12)=1.05;
yt(30)=1.3;
jalign(49)=3;
for j=1:50
    if(jalign(j)==1)
    text(dat(j,idx)*1.1*xt(j),dat(j,idy)*yt(j),datstr{j},'fontsize',8,...
        'fontweight','bold','HorizontalAlignment','left',...
        'VerticalAlignment','middle'); 
    hold on;
    elseif(jalign(j)==2)
    text(dat(j,idx)*0.9*xt(j),dat(j,idy)*yt(j),datstr{j},'fontsize',8,...
        'fontweight','bold','HorizontalAlignment','right',...
        'VerticalAlignment','middle'); 
    hold on;
    elseif(jalign(j)==3)
    text(dat(j,idx)*xt(j),dat(j,idy)*0.75*yt(j),datstr{j},'fontsize',8,...
        'fontweight','bold','HorizontalAlignment','center',...
        'VerticalAlignment','top'); 
    hold on;
    elseif(jalign(j)==4)
    text(dat(j,idx)*xt(j),dat(j,idy)*1.2*yt(j),datstr{j},'fontsize',8,...
        'fontweight','bold','HorizontalAlignment','center',...
        'VerticalAlignment','bottom'); 
    hold on;
        
    end
end

% xlabel('Year');
xlabel('T_i [keV]'); 
ylabel('n_0\tau_ET_i [m^{-3}\cdot{}s\cdot{}keV]');
ylim([1e11,1e23]);
xlim([1e-2,1e2]);

% legend('DT breakeven','Tokamak','ST','Stellarator','Pinch','RFP','Spheromak',...
%     'FRC','Mirror','Laser ICF','MagLIF','location','best');
legend('DT��ʧ�൱','�п�����','���λ�','������','����','��������','������',...
    '����λ��','�ž�','�������Լ��','MagLIF','location','best');
legend('boxoff');

% grid on;
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');
% plot([1e-1,1e-1],[1e11,1e23],'--','Color',[0.1,0.1,0.1]);
% plot([1e0,1e0],[1e11,1e23],'--','Color',[0.1,0.1,0.1]);
% plot([1e1,1e1],[1e11,1e23],'--','Color',[0.1,0.1,0.1]);
% ax=gca;
% % ax.XGrid='on';
% ax.YGrid='on';

%%


set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);
% print(gcf,'-dpdf','-painters','tst.pdf');
print(gcf,'-dpdf','lawsondat.pdf');
% print(gcf,'-dpng','lawsondat.png');

