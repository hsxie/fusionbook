% 22-04-16 21:05 Huasheng XIE, huashengxie@gmail.com
% plot Zeff with impurity

close all; clear; clc;

fimp=0.01;
Zimp=74;

% Zeff=((1-fimp)+fimp*Zimp^2)/((1-fimp)+fimp*Zimp)

gimp=(1+fimp*Zimp^2)*(1+fimp*Zimp)