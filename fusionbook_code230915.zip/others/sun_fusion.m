% 2022-03-15 21:03 calcualte data Sun fusion data

close all; clear; clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% http://solar-center.stanford.edu/vitalstats.html
% Solar radiation, 3.83X10^23 kW
% Chemical composition of photosphere (by weight, in percent):
% Hydrogen 73.46
% Helium 24.85
% Oxygen 0.77
% Carbon 0.29
% Iron 0.16
% Neon 0.12
% Nitrogen 0.09
% Silicon 0.07
% Magnesium 0.05
% Sulfur 0.10

Msun=1.99e30; % kg
rho=1.5e5; % kg/m^3

fH=0.75/(0.75/1+0.25/4);
fHe=1-fH;
nH=rho/((fH*1+fHe*4)*mp)*fH

NH=Msun*0.75/mp

% (fH*1+(1-fH)*4)=0.75

% ne=1e31; % m^-3, density, core
R=6.96e8; % m
Rcore=0.24*R;

Vcore=4/3*pi*Rcore^3;
Vsun=4/3*pi*R^3;
Vcore/Vsun

% 4/3*pi*R^3*1.4e3

sgmv=1e-50;
% sgmv=1.3533e-49;
% sgmv=2.0e-49;

Pcore0=nH^2*sgmv*1.44*1e6*1.6e-19 % W/m^3
% Pcore=nH^2*sgmv*1.44*1e6*1.6e-19*Vcore % W 
Pcore=nH^2*sgmv*26.73/2*1e6*1.6e-19*Vcore % W 

Prad=1.36e3*(4*pi*(1.5e11)^2)
%%
Nrad=Prad/(26.73*1e6*1.6e-19)
Npfus=4*Nrad
mpfus=Npfus*mp
ratioH=Npfus/NH
PradV=Prad/Vcore

% 2*Npfus=2*nH^2*sgmv*Vcore
sgmv_require=2*Npfus/(2*nH^2*Vcore)

%%
% Pkg=(1e31)^2*1e-47*1.44*1e6*1.6e-19*(1/1.67e-27)/1e31 % W/kg

Pkg=(nH)^2*sgmv*1.44*1e6*1.6e-19*(1/1.67e-27)/nH % W/kg


