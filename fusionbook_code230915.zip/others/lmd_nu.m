% 2022-04-08 09:56 plot photon mean free path of absorb in plasma
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
c=2.99792458e8; % m/s
h=6.6261e-34; % Js

ne=1e21; Zeff=1;

TkeV=10;
kBT=1e3*TkeV*qe;
nu=10.^(16:1:20);
% lmd=0.75*sqrt(3*kBT/(2*pi))*h*c*me^1.5*nu.^3./(ne^2*Zeff*qe^4);
% lmd=0.75*sqrt(3*kBT/(2*pi))*h*c*me^1.5*nu.^3./(ne^2*Zeff*qe^6);
lmd=(3/(16*pi))*sqrt(3*kBT/(2*pi))*h*c*me^1.5*nu.^3./(ne^2*Zeff*(qe^2/(4*pi*epsilon0))^3);
lmd2=7e-5*sqrt(TkeV)*nu.^3./((ne*1e-6)^2)*1e-2;

c_spitzer_cm=4/3*sqrt(2*pi/(3*(kB)))*(1e6)^2/(h*c*me^1.5)*(qe^2/(4*pi*epsilon0))^3*1e-2
c_spitzer_m=4/3*sqrt(2*pi/(3*(kB)))*(1e0)^2/(h*c*me^1.5)*(qe^2/(4*pi*epsilon0))^3*1e0
c_spitzer_m2=4/3*sqrt(2*pi/(3*(1e3*qe)))*(1e0)^2/(h*c*me^1.5)*(qe^2/(4*pi*epsilon0))^3*1e0
% c_spitzer=4/3*sqrt(2*pi/(3*(1e3*qe)))*(1e6)^2/(h*c*me^1.5)*(qe^2/(4*pi*epsilon0))^3*1e2
% (3/(16*pi))*sqrt(3*kBT/(2*pi))*h*c*me^1.5*nu.^3./(ne^2*Zeff*(qe^2/(4*pi*epsilon0))^3);

g=1.11;
% c_lmd=(3/(g*16*pi))*sqrt(3*(1e3*qe)/(2*pi))*h*c*me^1.5/((qe^2/(4*pi*epsilon0))^3)
c_lmd=(3/(g*4))*sqrt(3*(1e3*qe)/(2*pi))*h*c*me^1.5/((qe^2/(4*pi*epsilon0))^3)



%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.45,0.7,0.5]);


loglog(nu,lmd,nu,lmd2,'linewidth',3);
%%
lmd(1)/lmd2(1)

%% P_cycl
qe^4/(3*pi*epsilon0*me^2*c)/511


2*mu0*qe^4/(3*pi*epsilon0*me^3*c^3)*(1e3*qe)^2



