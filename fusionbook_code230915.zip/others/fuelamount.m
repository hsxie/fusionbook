% 2022-03-22 21:14
% calculate fuel amount
close all; clear; clc;

% constants
% kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
% mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

mh=1*mp;
md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;
mLi=6*mp;

Ydt=17.59*1e6*qe; % MeV -> J
% Ydt=3.52*1e6*qe; % MeV -> J
Ydd=0.5*(3.27*1+4.04)*1e6*qe/2; % MeV -> J
% Ydd=(3.27*3/4+4.04)*1e6*qe; % MeV -> J
Ydhe=18.35*1e6*qe; % MeV -> J
Ypb=8.68*1e6*qe; % MeV -> J
YpLi=4.02*1e6*qe; % MeV -> J

m=mt; Y=Ydt;
m=md; Y=Ydd;
m=mhe; Y=Ydhe;
m=mp; Y=Ypb;
% m=mb; Y=Ypb;
m=mLi; Y=YpLi;

Nkg=1/m;
TWyear=1e12*365*24*60*60; % TW*year -> J
kg=20*TWyear/(Nkg*Y)


