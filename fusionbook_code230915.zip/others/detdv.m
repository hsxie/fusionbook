% 2022-03-19 11:19 to calculate sigma*v intergal
% (v1,v2)->(vc,v)
% a=m2/(m1+m2), b=-m1/(m1+m2)
syms a b m1 m2;
a=m2/(m1+m2); b=-m1/(m1+m2);
Jac=[1,0,0,a,0,0;
    0,1,0,0,a,0;
    0,0,1,0,0,a;
    1,0,0,b,0,0;
    0,1,0,0,b,0;
    0,0,1,0,0,b];
Jdv=det(Jac)

%  
% Jdv = -(a - b)*(a^2 - 2*a*b + b^2)=-1