% 2022-04-25 15:37, Hua-sheng XIE, huashengxie@gmail.com
% plot rho*R vs G for Lawson diagram
% 22-04-27 08:17 add HB and also cs=sqrt(Teff*qe*1e3/mi), instead sqrt(2*Teff*qe*1e3/mi)
close all;clear;clc;

qe=1.6022e-19; % C
mp=1.6726e-27; % kg

md=2*mp;
mt=3*mp;
mhe=3*mp;
mb=11*mp;

% Teff=1:1.0:1000.0; % keV
Teff=10.^(-0.0:0.005:3.0); % keV
Ti=Teff;
G=1;

% icase=1;
for icase=1:4
    if(icase==1)
        Z1=1.0; Z2=1.0;
        x1=0.5; x2=(1-x1);
        Zi=x1*Z1+x2*Z2;
        
        mi=(x1*md+x2*mt)/(x1+x2);
        
        Ydt=17.59*1e6*qe; % MeV -> J
        sgmvdt=fsgmv(Teff,1);
        rhoRdt=G*3/2*(Zi+1.0).*(Teff*qe*1e3).^(1.5)./(x1*x2*sgmvdt*Ydt)*sqrt(1*mi);
%         csdt=sqrt(2*Teff*qe*1e3/mi);
        csdt=sqrt(1*Teff*qe*1e3/mi); % 22-04-27 08:17
        HBdt=8*mi*csdt./sgmvdt;
        
    elseif(icase==2)
        delta12=1; % like particle, =1
        Z=1; Zi=1; Zeff=1;
        x1=1; x2=1;
        mi=md;
        
        Ydd=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
        Yddc=0.5*43.25*1e6*qe; % MeV -> J
        sgmvdd=fsgmv(Teff,2);
        %     sgmvdd=fsgmvdd1(Teff,0)+fsgmvdd2(Teff,0);
        
        rhoRdd=G*3/2*(Zi+1.0).*(Teff*qe*1e3).^(1.5)./(x1*x2/(1+delta12)*sgmvdd*Ydd)*sqrt(1*mi);
        rhoRddc=G*3/2*(Zi+1.0).*(Teff*qe*1e3).^(1.5)./(x1*x2/(1+delta12)*sgmvdd*Yddc)*sqrt(1*mi);
        
        csdd=sqrt(1*Teff*qe*1e3/mi);
        HBdd=8*mi*csdd./sgmvdd/(1+delta12);
    elseif(icase==3)
        
        x1=0.5; x2=(1-x1); Z1=1.0; Z2=2.0;
        Zi=x1*Z1+x2*Z2;
        mi=(x1*md+x2*mhe)/(x1+x2);
        
        Ydhe=18.35*1e6*qe; % MeV -> J
        sgmvdhe=fsgmv(Teff,3);
        %     sgmvdhe=fsgmvdhe(Teff,0);
        
        rhoRdhe=G*3/2*(Zi+1.0).*(Teff*qe*1e3).^(1.5)./(x1*x2*sgmvdhe*Ydhe)*sqrt(1*mi);
        
        csdhe=sqrt(1*Teff*qe*1e3/mi);
        HBdhe=8*mi*csdhe./sgmvdhe;
    elseif(icase==4)
        
        x1=0.5; x2=(1-x1); Z1=1.0; Z2=5.0;
        Zi=x1*Z1+x2*Z2;
        mi=(x1*mp+x2*mb)/(x1+x2);
        
        Ypb=8.68*1e6*qe; % MeV -> J
        %     sgmvpb=fsgmvpb(Teff,0);
        sgmvpb4=fsgmv(Teff,4);
        sgmvpb5=fsgmv(Teff,5);
        
        rhoRpb=G*3/2*(Zi+1.0).*(Teff*qe*1e3).^(1.5)./(x1*x2*sgmvpb5*Ypb)*sqrt(1*mi);
        
        cspb=sqrt(1*Teff*qe*1e3/mi);
        HBpb=8*mi*cspb./sgmvpb5;
    end
end
%%
close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.25,0.65,0.55]);


ax1=axes('Position',[0.1,0.14,0.37,0.8]);
loglog(Teff,rhoRdt,Teff,rhoRdd,Teff,rhoRdhe,Teff,rhoRpb,'linewidth',3);

ylim([1e-1,1e4]);ylabel('\rho{}R [kg\cdot{}m^{-2}]');
% xlim([5,1000]);
xlim([1,1000]);
xlabel('T_i [keV]');
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');

leg1=legend(['D-T, Y=',num2str(Ydt/(1e6*qe),3),'MeV'],...
    ['D-D, Y=',num2str(Ydd/(1e6*qe),3),'MeV'],...
    ['D-^3He, Y=',num2str(Ydhe/(1e6*qe),3),'MeV'],...
    ['p-^{11}B Sikora16, Y=',num2str(Ypb/(1e6*qe),3),'MeV'],...
    'Location','best');
%     '${\rm ^3He+{}^3He} \to {\rm {}^4He +2p+12.86MeV}$',...
legend('boxoff');
set(leg1,'FontSize',9);
text(200,2e-1,['G=',num2str(G,3)],'FontSize',14);

ax2=axes('Position',[0.58,0.14,0.37,0.8]);
% loglog(Teff,csdt,Teff,csdd,Teff,csdhe,Teff,cspb,'linewidth',3);
loglog(Teff,HBdt,Teff,HBdd,Teff,HBdhe,Teff,HBpb,'linewidth',3);
xlabel('T_i [keV]');
ylim([1e1,1e6]);
ylabel('H_B  [kg\cdot{}m^{-2}]');
% xlim([5,1000]);
xlim([1,1000]);
grid on; set(gca,'YMinorGrid','off','XMinorGrid','off');


% 
% %     loglog(Teff,ntauEdt,Teff,ntauEdd,Teff,ntauEdhe,Teff,ntauEpb4,...
% %         Teff,ntauEpb5,'--',Teff,ntauEpp*1e-25,':',...
% %         Teff,ntauEdt1,':',Teff,ntauEdhe1,':','linewidth',3);
% loglog(Teff,ntauEdt,Teff,ntauEdd,Teff,ntauEdhe,Teff,ntauEpb4,...
%     Teff,ntauEpb5,'--',Teff,ntauEddc,'-.',Teff,ntauEpp*1e-23,':','linewidth',3);
% ylim([1e18,1e24]);ylabel('n_e\tau_E [m^{-3}\cdot{}s]');
% xlim([1,1000]);
% xlabel('T_i [keV]');
% 
% % grid on;
% % title(['Q=\infty, without radidation, T_e/T_i=',num2str(Te_o_Ti,3)]);
% leg1=legend(['D-T, 0.5:0.5, Y_+=',num2str(Ydt/(1e6*qe),3),'MeV'],...
%     ['D-D, Y_+=',num2str(Ydd/(1e6*qe),3),'MeV'],...
%     ['D-^3He, 0.634:0.366, Y_+=',num2str(Ydhe/(1e6*qe),3),'MeV'],...
%     ['p-^{11}B Nevins00, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
%     ['p-^{11}B Sikora16, 0.795:0.205, Y_+=',num2str(Ypb/(1e6*qe),3),'MeV'],...
%     ['Catalyzed D-D, Y_+=',num2str(Yddc/(1e6*qe),3),'MeV'],...
%     ['p-p\times10^{-23}, Y_+=',num2str(Ypp/(1e6*qe),3),'MeV'],...
%     'Location','southwest');
% %     '${\rm ^3He+{}^3He} \to {\rm {}^4He +2p+12.86MeV}$',...
% legend('boxoff');
% set(leg1,'FontSize',9);
% % set(leg1,'Interpreter','latex','FontSize',15);
% % set(leg1,'TextColor',[0.2,0.0,0.8]);
% % set(leg1,'FontWeight','bold');
% % ylim([1e17,1.0e25]);
% 
% subplot(122);
% loglog(Teff,ntauEdt.*Teff,Teff,ntauEdd.*Teff,Teff,ntauEdhe.*Teff,...
%     Teff,ntauEpb4.*Teff,Teff,ntauEpb5.*Teff,'--',Teff,ntauEddc.*Teff,'-.',...
%     Teff,ntauEpp.*Teff*1e-23,':','linewidth',3);
% ylim([1e20,1e25]);ylabel('n_e\tau_E{}T_i [m^{-3}\cdot{}s\cdot{}keV]');
% xlim([1,1000]);
% xlabel('T_i [keV]');

% set(gca,'LooseInset',[0,0,0,0]);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters',['rhoR_icf.pdf']);
