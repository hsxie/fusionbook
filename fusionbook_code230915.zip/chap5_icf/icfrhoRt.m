% 2022-04-26 14:00, Hua-sheng XIE, huashengxie@gmail.com
% ICF rho(R) vs t diagram
%
close all;clear;clc;


close all;
figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.45,0.45,0.45]);


ax1=axes('Position',[0.12,0.16,0.8,0.8]);


r=0:0.001:20;dr=r(2)-r(1);

rho=(1-tanh(500*(r-1)))/2; 
plot(r,rho,'k:','linewidth',3); hold on;

ktt=[18,    6,   3.5,  2.8, 2.4,  2.1, 1.85, 1.5];
% xtt=-[0.0, 0.2, 0.45, 0.6, 0.75, 1.2, 3.0];
xtt=0.*ktt;
for jt=1:length(ktt)
%     rho=((1-tanh(ktt(jt)*(r-1-xtt(jt))))/2).^0.5;
    rho=((1-tanh(ktt(jt)./(r+0.01).*(r-1-xtt(jt))))/2);
    V=sum(rho)*dr;
    xt=(1-V);
    rt=r+1*xt;
    plot(rt,rho,'-','linewidth',3); hold on;
end

ta1=annotation('textarrow',[0.46,0.2],[0.59,0.29]);
% ta1.String='t';
ta1.LineWidth=2;
text(0.47,0.55,'t','Fontsize',15);

ylim([0,1.5]);
xlim([0,2]);

xlabel('r/r_0');
ylabel('n/n_0');

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters',['icfrhoRt.pdf']);
