% 2022-04-15 13:59 RR model profile
close all;clear;clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s


Be=1.0;
Rs=0.1;
Pm=Be^2/(2*mu0);

rr=(0:0.001:2.0)*Rs;
u=2*rr.^2/Rs^2-1;


close all;

figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.45,0.65,0.5]);

ax1=axes('Position',[0.1,0.14,0.37,0.8]);

K=0.5;
p=Pm*sech(K*u);
Bz=sqrt((Pm-p)*(2*mu0));
beta=p/Pm;
betalocal=(2*mu0)*p./Bz.^2;
plot(rr/Rs,beta,'-',rr/Rs,Bz/Be,'-',rr/Rs,betalocal/100,'-','linewidth',3); hold on;
legend('\beta','B/B_e','0.01\times\beta_{local}','Location','best','AutoUpdate','off'); legend('boxoff');
plot([1,1],[0,1.5],'k--','linewidth',2);
xlabel('r/R_s'); ylabel('\beta & B');
ylim([0,1.5]);
grid on;
text(1.2,0.1,['K=',num2str(K,3)],'FontSize',14);
% set(leg1,'fontsize',13);

ax2=axes('Position',[0.58,0.14,0.37,0.8]);
K=2.0;
p=Pm*sech(K*u);
Bz=sqrt((Pm-p)*(2*mu0));
beta=p/Pm;
betalocal=(2*mu0)*p./Bz.^2;
plot(rr/Rs,beta,'-',rr/Rs,Bz/Be,'-',rr/Rs,betalocal/100,'-','linewidth',3); hold on;
legend('\beta','B/B_e','0.01\times\beta_{local}','Location','best','AutoUpdate','off'); legend('boxoff');
plot([1,1],[0,1.5],'k--','linewidth',2);
xlabel('r/R_s'); ylabel('\beta & B');
ylim([0,1.5]);
grid on;
text(1.2,0.1,['K=',num2str(K,3)],'FontSize',14);

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters','betaRR.pdf');