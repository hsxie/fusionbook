% 2021-12-12 20:27
% Plot profile
close all; clear; clc;

x=0:0.002:1;
% h=figure('unit','normalized','Position',[0.01 0.2 0.4 0.5],...
%     'DefaultAxesFontSize',15);

figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesLineWidth',2,...
    'position',[0.01 0.2 0.45 0.4]);


ssp=[0.4,0.5,0.8,1.0,1.5,2.0,3.0,5.0];
np=length(ssp);
legstr={};
for jp=1:np
Sn=ssp(jp);
fx=(1-x.^2).^Sn;
plot(x,fx,'linewidth',3); hold on;
legstr{jp}=['S=',num2str(Sn)];
end
xlabel('x=r/a'); ylabel('n(x), T(x)');
legend(legstr,'location','best');legend('boxoff');

text(0.7,0.9,'n(x),T(x)=(1-x^2)^S','fontsize',15);


% save figure

pltstr=['plt_nTx_Sn=',num2str(Sn)];

set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);
print(gcf,'-dpdf','-painters',[pltstr,'.pdf']);

% print(gcf,'-dpng',[pltstr,'.png']);
