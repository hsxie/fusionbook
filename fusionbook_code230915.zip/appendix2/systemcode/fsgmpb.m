% Hua-sheng XIE, huashengxie@gmail.com, 2018-11-22 13:37
% Ref: [1] Bosch & Hale, 1992, fusion cross-sections
% [2] Nevins & Swain, 2000, p- 11 B
% 2020-04-15 23:42 rewrite to function
% 22-11-28 15:55 fixed bug for E>400keV

function sigmapb=fsgmpb(E)

% E=10.^(0:0.002:3.0); % keV

% 5. p + B11 -> 3He4 + 8.7MeV
BGpb=sqrt(22.589e3);
% ind1=find(abs(E-400)==min(abs(E-400)));
% ind2=find(abs(E-642)==min(abs(E-642)));
% E1=E(1:ind1); E2=E((ind1+1):ind2)/100-4;
% E3=E((ind2+1):end);

ind1=find(E<400); ind2=find(E>=400 & E<642); ind3=find(E>=642 & E<4700);
% ind3=find(E>=642 & E<3500);
% E1=E(ind1); E2=E(ind2); E3=E(ind3); % wrong
E1=E(ind1); E2=E(ind2)/100-4; E3=E(ind3); % 22-12-01 22:19

Spb1=1.97e5+0.24e3*E1+2.31e-1*E1.^2+1.82e7./((E1-148).^2+2.35^2);
Spb2=3.30e5+66.1e3*E2-20.3e3*E2.^2-1.58e3*E2.^5;
Spb3=4.38e3+2.57e9./((E3-581.3).^2+85.7^2)+5.67e8./((E3-1083).^2+234^2)+...
    1.34e8./((E3-2405).^2+138^2)+5.68e8./((E3-3344).^2+309^2);
% Spb=[Spb1,Spb2,Spb3];
% sigmapb=Spb./E.*exp(-BGpb./sqrt(E))*1e-28; % unit: mb (1e-31 m^2) -> m^-2
% sigmapb(E>3500 | E<0.5)=NaN;
% sigmapb(isnan(E))=NaN;

Spb=0.*E;  % 22-11-16 08:27 to check use 0 or NaN
Spb(ind1)=Spb1;
Spb(ind2)=Spb2;
Spb(ind3)=Spb3;
sigmapb=Spb./(E.*exp(BGpb./sqrt(E)))*1e-28; % unit: mb (1e-31 m^2) -> m^2

