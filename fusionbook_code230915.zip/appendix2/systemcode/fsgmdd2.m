% Hua-sheng XIE, huashengxie@gmail.com, 2018-11-22 13:37
% Ref: [1] Bosch & Hale, 1992, fusion cross-sections
% [2] Nevins & Swain, 2000, p- 11 B
% 2020-04-15 23:42 rewrite to function

function sigmadd2=fsgmdd2(E)

% E=10.^(0:0.002:3.0); % keV

% 3. D + D -> n + He3 + 3.25MeV, 0.5-4900 keV
BGdd2  =  31.3970;
Add2   =  [5.3701e4,  3.3027e2,   -1.2706e-1,   2.9327e-5,   -2.5151e-9  ];
Bdd2   =  [0.0,       0.0,        0.0,          0.0          ];
Sdd2=(Add2(1)+Add2(2)*E+Add2(3)*E.^2+Add2(4)*E.^3+Add2(5)*E.^4)./(1.0+...
    Bdd2(1)*E+Bdd2(2)*E.^2+Bdd2(3)*E.^3+Bdd2(4)*E.^4);
sigmadd2=Sdd2./(E.*exp(BGdd2./sqrt(E)))*1e-31; % unit: mb (10e-31 m^2) -> m^-2
% sigmadd2(E>4900 | E<0.5)=NaN;
