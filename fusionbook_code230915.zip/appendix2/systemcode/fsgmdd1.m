% Hua-sheng XIE, huashengxie@gmail.com, 2018-11-22 13:37
% Ref: [1] Bosch & Hale, 1992, fusion cross-sections
% [2] Nevins & Swain, 2000, p- 11 B
% 2020-04-15 23:42 rewrite to function

function sigmadd1=fsgmdd1(E)

% E=10.^(0:0.002:3.0); % keV

% 2. D + D -> p + T + 4.0MeV, 0.5-5000 keV
BGdd1  =  31.3970;
Add1   =  [5.5576e4,  2.1054e2,   -3.2638e-2,   1.4987e-6,   1.8181e-10];
Bdd1   =  [0.0,       0.0,        0.0,          0.0          ];
Sdd1=(Add1(1)+Add1(2)*E+Add1(3)*E.^2+Add1(4)*E.^3+Add1(5)*E.^4)./(1.0+...
    Bdd1(1)*E+Bdd1(2)*E.^2+Bdd1(3)*E.^3+Bdd1(4)*E.^4);
sigmadd1=Sdd1./(E.*exp(BGdd1./sqrt(E)))*1e-31; % unit: mb (10e-31 m^2) -> m^-2
% ind=find(E>5000 || E<0.5);
% sigmadd1(E>5000 | E<0.5)=NaN;