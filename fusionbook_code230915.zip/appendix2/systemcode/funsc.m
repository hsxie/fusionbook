% Hua-sheng XIE, huashengxie@gmail.com, ENN, 2022-05-16 08:07
% Tokamak system code for physics design, including D-T, D-D, D-He3, p-B11
% Ref: [1]Costley2015, TESC (Tokamak Energy System Code)
%      [2]Freidberg2015
% 22-05-31 11:34 add ST tau_E scalings

function [Eth,H98,HST,Pheat,Pn,Pfus,Pwall,Qfus,betaN,betaT,nbar_o_nGw,q,...
    Pbrem,Pcycl,Vp,betap,fTavg,fnavg,Sp,ne0,M]=...
    funsc(R0,A,kappa,delta,Sn,ST,ni0,Ti0,fT,fsig,...
    f1,BT0,Ip,tauE,fHe,fimp,Zimp,Rw,g,icase)
% constants
% kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
% mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m

a=R0/A; % m
% Rc=R0-a-g; % radius of centre column, m

Ad=R0/(g+a);
% Vd=(2*pi^2*kappa*(Ad-delta)+16*pi*kappa*delta/3)*(a+g)^3; % device volume
Vp=(2*pi^2*kappa*(A-delta)+16*pi*kappa*delta/3)*a^3; % plasma volume, % to check

Sw=(4*pi^2*Ad*kappa^0.65-4*kappa*delta)*(a+g)^2; % first wall area
Sp=(4*pi^2*A*kappa^0.65-4*kappa*delta)*a^2; % plasma wall area, to check

Te0=fT*Ti0; % keV
ZHe=2;
% f12=1.0-fHe*ZHe-fimp*Zimp;
f12=1.0-fHe-fimp;
n120=f12*ni0;
nHe0=fHe*ni0; nimp0=fimp*ni0;

x=0:0.01:1.0; dx=x(2)-x(1);
Tx=Ti0*(1-x.^2).^ST;
fTavg=nansum(x.*(1-x.^2).^ST)/nansum(x);  % volum average, 21-12-16 18:53
fnavg=nansum(x.*(1-x.^2).^Sn)/nansum(x);

if(icase==1) % D-T
    
    delta12=0;
    Z1=1.0; Z2=1.0; A1=2; A2=3;
    x1=f1; x2=(1-x1);
    fion=0.2;
    Y=17.59*1e6*qe; % MeV -> J
    
    Phi=fsig*2*nansum((1-x.^2).^(2*Sn).*(fsgmv(Tx,1)).*x*dx);
    
elseif(icase==2 || icase==6) % D-D
    
    delta12=1; % like particle, =1
    Z1=1.0; Z2=1.0; A1=2; A2=2;
    x1=1.0; x2=1.0;
    
    if(icase==2)
        fion=(3.27/4+4.04)/(3.27+4.04);
        Y=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
    elseif(icase==6) % cat D-D
        fion=26.73/43.25;
        Y=0.5*43.25*1e6*qe; % MeV -> J
    end
    
    Phi=fsig*2*nansum((1-x.^2).^(2*Sn).*(fsgmv(Tx,2)).*x*dx);
    
elseif(icase==3)
    
    delta12=0;
    Z1=1.0; Z2=2.0; A1=2; A2=3;
    x1=f1; x2=(1-x1);
    
    fion=1.0;
    Y=18.35*1e6*qe; % MeV -> J
    
    Phi=fsig*2*nansum((1-x.^2).^(2*Sn).*(fsgmv(Tx,3)).*x*dx);
    
elseif(icase==4 || icase==5)
    
    delta12=0;
    Z1=1.0; Z2=5.0; A1=1; A2=11;
    x1=f1; x2=(1-x1);
    
    fion=1.0;
    Y=8.68*1e6*qe; % MeV -> J
    if(icase==4)
        Phi=fsig*2*nansum((1-x.^2).^(2*Sn).*(fsgmv(Tx,4)).*x*dx);
    elseif(icase==5)
        Phi=fsig*2*nansum((1-x.^2).^(2*Sn).*(fsgmv(Tx,5)).*x*dx);
    end
    
end
M=(x1*A1+x2*A2)/(1+delta12); % mass number

n10=x1*n120; 
n20=x2*n120;
ne0=(n10*Z1+n20*Z2)/(1+delta12)+nHe0*ZHe+nimp0*Zimp; % central electron density, m^-3
% Zi=ne0/ni0;
Zeff=((n10*Z1^2+n20*Z2^2)/(1+delta12)+nHe0*ZHe^2+nimp0*Zimp^2)/ne0;

Pfus=Y/(1+delta12)*n10*n20*Phi*Vp*1e-6; % fusion power, MW

mec2=511; % keV
Pbrem=5.34e-37*ne0^2.*sqrt(Te0).*(Zeff*(1/(1+2*Sn+0.5*ST)+...
    0.7936/(1+2*Sn+1.5*ST)*(Te0./mec2)+...
    1.874/(1+2*Sn+2.5*ST)*(Te0./mec2).^2)+...
    3/sqrt(2)/(1+2*Sn+1.5*ST)*(Te0./mec2))*1e-6*Vp; % MW, to check 1e-6

neff=ne0/1e20/(1+Sn); % volume average density
aeff=a*kappa^0.5; % effective minor radius
% V=2*pi*R0*pi*aeff^2; % an approximation to the plasma volume
Teff=Te0*nansum((1-x.^2).^ST)*dx; % effective temperature
Pcycl=4.14e-7*(neff/1e0)^0.5*Teff^2.5*BT0^2.5*(1-...
    Rw)^0.5*aeff^-0.5*(1+2.5*Teff/511)*Vp*1e0; % MW

betaT=2*mu0*(ni0*Ti0+ne0*Te0)*1e3*qe/BT0^2/(1+Sn+ST);

Eth=1.5*(ni0*Ti0+ne0*Te0)*1e3*qe/(1+Sn+ST)*Vp*1e-6; % stored thermal energy, MJ

Pth=Eth/tauE; % W

Pheat=Pcycl+Pbrem+Pth-fion*Pfus; % MW

Qfus=Pfus/Pheat; % Pfus/Pheat
if(Qfus<=0 || Qfus>1000)
    Qfus=1000; % set max Qfus, 21-12-16 18:45
end

% nbar=ne0*2/(2+Sn); % to update
nbar=ne0*sqrt(pi)/2*gamma(Sn+1)/gamma(Sn+1.5);
betaN=100*betaT/(Ip/(a*BT0)); % Eq.(17): %, MA, m, T
betap=(25/betaT)*((1+kappa^2)/2)*(betaN/100)^2; % Eq.(18), 21-12-12 22:03 fix a bug

% Ip=(100*betaT)*(a*BT0)/betaN;
q=5*BT0*a^2*kappa/(R0*Ip); % safety factor, Eq.(13)
nGw=1e20*Ip/(pi*a^2); % Greenwald density, m^-3

nbar_o_nGw=nbar/nGw;
Pn=Pfus*(1-fion); % neutron power, MW

Pwall=(Pfus+Pheat)/Sw; % MW/m^2

% ndt0=2.0e20; % m^-3
% T0=15; % keV
% BT0=7; % T
%
% R0=1.8; % m
% A=2.0;
%
% kappa=2.5; % elongation
% delta=0.5; % triangularity
% Sn=0.5; % exponents of the density profiles
% ST=0.6; % exponents of the temperature profiles
%
% betaN=3.0;
% H98=1.8;

% fHe=0.0; % helium fraction
% fimp=0.0; % impurity ion
% Zimp=1; % impurity ion fraction
%
% Rw=0.6; % wall reflectivity to cyclotron radiation
% g=0.0; % plasma wall gap

% tauEx=@(Pcd)0.048*(ni0/1e20)*T0*Vp/((1+Sn+ST)*(Palpha+Pcd-Pbrem-Pcycl));
PLx=@(Pheat)fion*Pfus+Pheat;
tauEIPB98x=@(Pcd)0.145*(Ip^0.93*R0^1.39*a^0.58*kappa^0.78*(nbar/1e20)^0.41*BT0^0.15*M^0.19)/PLx(Pheat)^0.69; % ITER IPB98y2 scaling

tauESTx=@(Pcd)0.066*(Ip^0.53*BT0^1.05*(nbar/1e19)^0.65*R0^2.66*kappa^0.78)/PLx(Pheat)^0.58; % 22-05-31 11:31 Kurskiev2022 ST scaling

H98=tauE/tauEIPB98x(Pheat); % 21-12-13 14:41
HST=tauE/tauESTx(Pheat); % 22-05-31 11:34

% Ploss=2*(ne020)^0.75*BT0*a*R0*(2/M)*((1+kappa^2)/2)^0.5; % threshold power to maintain the H mode
% % PLHmartin08=4.46e-10*1e-6*(ne0)^0.717*BT0^0.803*Sp^0.941/M; % 21-08-12 08:24 Jean2011
% PLHmartin08=0.0488*(ne020)^0.717*BT0^0.803*Sp^0.941/M; % 21-08-12 09:50 Martin08 /M
% PLHmartin08b=2.15*(ne020)^0.782*BT0^0.772*a^0.975*R0^0.999/M; % 21-08-12 09:58 Martin08 /M

end
