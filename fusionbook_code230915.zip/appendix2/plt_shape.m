% 2021-12-12 09:30
% Plot tokamak configuration/shape
close all; clear; clc;

kappa=2.0;
delta=0.5;
R0=2.0;
A=2.0;
a=R0/A;
g=0.1;

% rr=[0.2:0.2:1.0,1.1];
rr=[(0.2:0.2:1.0)*a,a+g];
nr=length(rr);

h=figure('unit','normalized','Position',[0.01 0.2 0.36 0.6],...
    'DefaultAxesFontSize',15);

axes('Position',[0.02,0.02,0.96,0.96]);

for jr=1:nr
% a=1.0;
r=rr(jr);
tt1=0.5*pi:0.002:1.502*pi;
R1=r*(1-delta)*cos(tt1)+R0-delta*r;
Z1=r*(1-delta)*sin(tt1)*(kappa/(1-delta));
tt2=1.5*pi:0.002:2.502*pi;
R2=r*(1+delta)*cos(tt2)+R0-delta*r;
Z2=r*(1+delta)*sin(tt2)*(kappa/(1+delta));
R=[R1,R2];Z=[Z1,Z2];
if(jr==nr)
plot(R,Z,'k-','linewidth',4); hold on;
elseif(jr==(nr-1))
plot(R,Z,'-','linewidth',3); hold on;
patch(R,Z,'m'); alpha(0.05);
else
plot(R,Z,'-','linewidth',2); hold on;
end
axis off;
end
arrow([-0.1 0],[4.0 0],10,'BaseAngle',60,'Width',2); % plot R axis arrow
text(3.9,-0.15,'R');
arrow([0 -2.5],[0 2.5],10,'BaseAngle',60,'Width',2); % plot Z axis arrow
text(-0.15,2.4,'Z');
plot(0,0,'k.','Markersize',21);text(-0.15,-0.15,'O');
axis equal;

Rmax=R0+a;
Rmin=R0-a;
Rdelta=R0-delta*a;
Zmax=a*kappa;
Rw=Rmax+g;
Rc=Rmin-g;

plot(R0,0,'r.','Markersize',20); hold on; text(R0-0.01,-0.15,'R_0','color','r');
plot(Rmax,0,'r.','Markersize',20); hold on; text(Rmax-0.01,-0.15,'R_{max}','color','r');
plot(Rmin,0,'r.','Markersize',20); hold on; text(Rmin-0.01,-0.15,'R_{min}','color','r');
plot(Rw,0,'r.','Markersize',20); hold on; text(Rw+0.05,0.1,'R_{w}','color','r');
plot(Rc,0,'r.','Markersize',20); hold on; text(Rc-0.2,0.1,'R_{c}','color','r');
plot(Rdelta,Zmax,'r.','Markersize',20); hold on; 
text(Rdelta-0.1,Zmax-0.2,'R_{\delta}, Z_{max}','color','r');

nR=length(R); jR=floor(0.55*nR);
arrow([R(jR)+0.2 Z(jR)-0.2],[R(jR) Z(jR)],10,'BaseAngle',60,'Width',1);
% text(R(jR)+0.2,Z(jR)-0.2,'Wall');
text(R(jR)+0.2,Z(jR)-0.2,'װ�ñ�');
arrow([Rdelta-g-0.2 -Zmax-0.2],[Rdelta -Zmax],10,'BaseAngle',60,'Width',1);
% text(Rdelta-g-0.2, -Zmax-0.2,'LCFS','HorizontalAlignment','right');
text(Rdelta-g-0.2, -Zmax-0.2,'����պϴ���','HorizontalAlignment','right');

text(2.8,1.8,['a=(R_{max}-R_{min})/2',10,'\kappa=Z_{max}/a',10,...
    '\delta=(R_0-R_\delta)/a',10,'g=R_w-R_{max}']);

rmax=max(R);zmax=max(Z);
% xlim([0,rmax]);
% ylim([-zmax,zmax]);

% save figure
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%   'PaperSize',[screenposition(3:4)]);

pltstr=['plt_shape_kappa=',num2str(kappa),',delta=',num2str(delta),...
    ',A=',num2str(A),',R0=',num2str(R0),',g=',num2str(g)];
% print(gcf,'-dpng',[pltstr,'.png']);
print(gcf,'-dpdf',[pltstr,'.pdf']);

