% 22-04-20 11:36 Hua-sheng XIE, huashengxie@gmail.com
% MCF fusion conditions, modified for all fuels
function [beta,Qfus,Pfus,Pbrem,Pcycl,Eth,f1]=fmcfpar(ne,Ti,fT,fsig,f1,B,Rw,tauE,icase)

% constants
% kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
% mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% input parameters
% ne=1e20; % m^-3
% f1=0.9;
% fT=1/2.5; % Ti/Te
% fsig=1.0; % <sigma*v>=fsig*<sigma*v>_M
% B=10; % T
% Rw=0.99;
% tauE=100; % s
% Ti=100; % keV
a=1.0; % m, default minor radius

% Teff=1:1.0:1000.0; % keV
% Teff=10.^(-0.0:0.0005:3.0); % keV
Teff=Ti;
Te=Ti*fT;

if(icase==1) % D-T
    Z1=1.0; Z2=1.0;
    x1=f1; x2=(1-x1);
    Zi=x1*Z1+x2*Z2;
    Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
    fion=0.2; delta12=0;
    ni=ne/Zi; n1=ni*x1; n2=ni*x2;
    
    Y=17.59*1e6*qe; % MeV -> J
    sgmvM=fsgmv(Teff,1);
    
elseif(icase==2 || icase==6) % D-D
    delta12=1; % like particle, =1
    f1=1; Z=1; Zi=1; Zeff=1;
    n1=ne; n2=ne; ni=ne;
    
    if(icase==2)
        fion=(3.27/4+4.04)/(3.27+4.04);
        Y=0.5*(3.27+4.04)*1e6*qe; % MeV -> J
    elseif(icase==6) % cat D-D
        fion=26.73/43.25;
        Y=0.5*43.25*1e6*qe; % MeV -> J
    end
    
    sgmvM=fsgmv(Teff,2);
elseif(icase==3)
    
    Z1=1.0; Z2=2.0;
    x1=f1; x2=1-x1;
    Zi=x1*Z1+x2*Z2;
    Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
    ni=ne/Zi; n1=ni*x1; n2=ni*x2;
    
    fion=1.0; delta12=0;
    Y=18.35*1e6*qe; % MeV -> J
    sgmvM=fsgmv(Teff,3);
    
elseif(icase==4 || icase==5)
    
    Z1=1.0; Z2=5.0;
    x1=f1; x2=1-x1;
    Zi=x1*Z1+x2*Z2;
    Zeff=(x1*Z1^2+x2*Z2^2)/(x1*Z1+x2*Z2);
    ni=ne/Zi; n1=ni*x1; n2=ni*x2;
    
    fion=1.0; delta12=0;
    Y=8.68*1e6*qe; % MeV -> J
    if(icase==4)
        sgmvM=fsgmv(Teff,4);
    elseif(icase==5)
        sgmvM=fsgmv(Teff,5);
    end
    
end


sgmv=sgmvM*fsig;
Pfus=(n1*n2)/(1+delta12)*sgmv*Y; % W/m^-3

mec2=511; % keV
Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*(Zeff*(1+0.7936*(Te./mec2)+...
    1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2))*1e6; % W/m^3

Pcycl=4.14e-7*(ne/1e20)^0.5*Te.^2.5*B^2.5*(1-Rw)^0.5*(1+...
    2.5*Te/511)/sqrt(a)*1e6; % W/m^3

beta=2*mu0*(ni*Ti+ne*Te)*1e3*qe/B^2;

Eth=1.5*(ni*Ti+ne*Te)*1e3*qe; % J/m^3

Pth=Eth/tauE;

Pheat=Pcycl+Pbrem+Pth-fion*Pfus;
Qfus=Pfus/Pheat; % Pfus/Pheat

if(Qfus<=0 || Qfus>1000)
    Qfus=1000; % set max Qfus, 21-12-16 18:45
end


end


