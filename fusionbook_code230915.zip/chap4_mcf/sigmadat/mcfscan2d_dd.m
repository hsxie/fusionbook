% Hua-sheng XIE, huashengxie@gmail.com, ENN, 2022-04-20 12:05
% Scan 2D parameters to calculate MCF fusion condition

close all; clear; clc;

%jscan     1    2   3     4    5      6   7    8
inputstr={'ne','Ti','fT','f1','fsig','B','Rw','tauE'};
inputlabel={'n_e[m^{-3}]','T_i[keV]','f_T','f_1','f_{\sigma}',...
    'B[T]','R_w','\tau_E[s]'};
% fuelstr={'D-T','D-D','D-{}^3He','p-{}^{11}B Nevins00','p-{}^{11}B Sikora16','Cat D-D'};
fuelstr={'D-T','D-D','D-{}^3He','p-{}^{11}B Nevins00','p-{}^{11}B Sikora16','�߻�D-D'};

icase=2;
inputrange={(0.5:0.5:10.0)*0.5e21; % 1. ne0[m^-3]
    10:2:120; % 2. Ti[keV]
    0.1:0.05:1.2; % 3. fT
    0.7:0.02:0.98; % 4. f1
    1:1:10; % 5. fsig
    1:2:50; % 6. BT0[T]
    0.9:0.05:0.995; % 7. Rw
    5:5:100; % 8. tauE[s]
    };
% inputrange={(0.1:0.1:2.0)*1e20; % 1. ne0[m^-3]
%     5:0.5:30; % 2. Ti[keV]
%     0.1:0.05:1.2; % 3. fT
%     0.7:0.02:0.98; % 4. f1
%     1:1:10; % 5. fsig
%     1:2:50; % 6. BT0[T]
%     0.9:0.05:0.995; % 7. Rw
%     5:5:100; % 8. tauE[s]
%     };
%%

% choose which two parameters to scan
jscanx=1;
jscany=2;

x=inputrange{jscanx};
y=inputrange{jscany};
[xx,yy]=ndgrid(x,y);
[dimx,dimy]=size(xx);

ff=zeros(10,dimx,dimy);
ff(1,:,:)=xx;
ff(2,:,:)=yy;

% set parameters
ne=1e21; % m^-3
f1=1.0;
fT=1.0; % Te/Ti
fsig=1.0; % <sigma*v>=fsig*<sigma*v>_M
B=15; % T
Rw=0.8;
tauE=20; % s
Ti=50; % keV

eval(['x00=',inputstr{jscanx},';']);
eval(['y00=',inputstr{jscany},';']);

for jdimx=1:dimx
    for jdimy=1:dimy
        jdimx
        jdimy
        
        eval([inputstr{jscanx},'=xx(jdimx,jdimy);']);
        eval([inputstr{jscany},'=yy(jdimx,jdimy);']);
        [beta,Qfus,Pfus,Pbrem,Pcycl,Eth,f1]=fmcfpar(ne,Ti,fT,fsig,f1,B,Rw,tauE,icase);
        
        ff(3,jdimx,jdimy)=beta;
        ff(4,jdimx,jdimy)=Qfus;
        ff(5,jdimx,jdimy)=Pfus/1e6; % MW/m^-3
        ff(6,jdimx,jdimy)=Pbrem/1e6; % MW/m^-3
        ff(7,jdimx,jdimy)=Pcycl/1e6; % MW/m^-3
        ff(8,jdimx,jdimy)=Eth/1e6; % MJ/m^-3
    end
end

ff0=ff;
%% plot
close all;

figure('unit','normalized','DefaultAxesFontSize',16,...
    'DefaultAxesFontWeight','bold',...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.65,0.7]);
% h=figure('unit','normalized','Position',[0.03 0.1 0.5 0.7],...
%     'DefaultAxesFontSize',13);

pltstr={'\beta','Q_{fus}','P_{fus}[W]','P_{brem}[W]','P_{cycl}[W]','E_{th}[J]'};

ff=ff0;
ff(imag(ff0)~=0)=NaN+1i*NaN;

Qmin=1;
Pfusmin=1e0; % MW
betamax=1.0;

ax1=axes('position',[0.1,0.12,0.84,0.81]);

contour(xx,yy,real(squeeze(ff(4,:,:))),[0.1,1,Qmin,2,5,10,100],...
    'linewidth',2,'showtext','on','Color','b');hold on; % Qfus

[CPfus,~]=contour(xx,yy,squeeze(ff(5,:,:)),[1,10,50,Pfusmin,100],...
    'linewidth',2,'showtext','on','Color','g');hold on; % Pfus

contour(xx,yy,real(squeeze(ff(3,:,:))),[0.01,0.05,0.1,0.5,betamax,betamax],...
    'linewidth',2,'showtext','on','Color','r','linestyle','--');hold on; % beta

contour(xx,yy,real(squeeze(ff(6,:,:))),[1,10,100],...
    'linewidth',2,'showtext','on','Color','c','linestyle',':');hold on; %  Pbrem

contour(xx,yy,real(squeeze(ff(7,:,:))),[1,10,100],...
    'linewidth',2,'showtext','on','Color','y','linestyle','-.');hold on; %  Pcycl

ind=find(squeeze(ff(3,:,:))<=betamax & squeeze(ff(5,:,:))>=Pfusmin ...
    & real(squeeze(ff(4,:,:)))>=Qmin);
strok=['\beta<',num2str(betamax),', Q>',num2str(Qmin),...
    ', P_{fus}>',num2str(Pfusmin),'MW/m^{3}'];

fok=0.*xx+NaN; fok(ind)=1;
plot(xx(ind),yy(ind),'kx','markersize',3); hold on;

% xlabel([inputlabel{jscanx},', Best region: ',strok]);
xlabel([inputlabel{jscanx},', �������: ',strok]);
ylabel(inputlabel{jscany});
% legend('Q_{fus}','P_{fus}[MW/m^{-3}]','\beta','P_{brem}[MW/m^{-3}]',...
%     'P_{cycl}[MW/m^{-3}]','Best region');%legend('boxoff');
legend('Q_{fus}','P_{fus}[MW/m^{3}]','\beta','P_{brem}[MW/m^{3}]',...
    'P_{cycl}[MW/m^{3}]','�������');%legend('boxoff');

str00='';
for jj=1:length(inputlabel)
    if(jj~=jscanx && jj~=jscany)
        str00=[str00,' ',inputlabel{jj},'=',num2str(eval(inputstr{jj})),','];
    end
%     if(jj==4)
%         str00=[str00,10];
%     end
end

title(['scan (',inputstr{jscanx},',',inputstr{jscany},'),',str00,' ',fuelstr{icase}]);
% title(['scan (',inputstr{jscanx},',',inputstr{jscany},'), n_e=',num2str(ne,3),...
%     'm^{-3}, T_i=',num2str(Ti,3),'keV, B=',num2str(B),'T,',10,...
%     '\tau_E=',num2str(tauE),...
%     's, f_p=',num2str(fp),', f_T=',num2str(fT),', f_\sigma=',num2str(fsig),...
%     ', R_{w}=',num2str(Rw,2)]);

% save figure
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);

prtstr=['mcfscan2d_icase=',num2str(icase),...
    ',jscanx=',num2str(jscanx),',jscany=',num2str(jscany),...
    ',ne=',num2str(ne,3),',Ti=',num2str(Ti,3),...
    ',B=',num2str(B,3),',f1=',num2str(f1),...
    ',fT=',num2str(fT),',fsig=',num2str(fsig),',tauE=',num2str(tauE),...
    ',Rw=',num2str(Rw)];
% print(gcf,'-dpng',[prtstr,'.png']);
print(gcf,'-dpdf',[prtstr,'.pdf']);

