% 2022-04-22 13:37, Hua-sheng XIE, huashengxie@gmail.com
% Solve the density of p, D, T, He3, He4 for D-fuels
% Reduced the model to three density equations and use fsolve.

function fpar=fdfuelpar(xx)
% Qfus=xx(1);
% beta=xx(2);

global Qfus0 beta0 Pfus0 Ti;
global ne sgmv1 sgmv2 sgmv3 sgmv4 tauE icase;

ne=exp(xx(1));
tauE=exp(xx(2));
B=exp(xx(3));

% constants
% kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
% mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% md=2*mp; mt=3*mp; mh=3*mp; ma=4*mp;
% Zp=1; Zd=1; Zt=1; 
% Zh=2; Za=2;

% mec2=511; % keV

% Ti=1:1.0:1000.0; % keV
% Ti=10.^(-0.0:0.0002:3.0); % keV

icase=2;
% if(icase==1)
%     Ti=14; ne=2.6e20; tauE=0.9; B=2.4;
% elseif(icase==2)
%     Ti=70; ne=5.9e20; tauE=2.9; B=7.4;
% elseif(icase==3)
%     Ti=70; ne=5.9e20; tauE=4.7; B=7.9;
% elseif(icase==4)
%     Ti=70; ne=5.8e20; tauE=4.7; B=7.8;
% elseif(icase==5)
%     Ti=70; ne=6.7e20; tauE=8.2; B=8.4;
% elseif(icase==6)
%     Ti=70; ne=6.8e20; tauE=8.2; B=8.5;
% end
x0=log([0.95, 0.01, 0.001]*ne);
% x0=([0.95, 0.01, 0.001]*ne);

Zh=2; Za=2; tauN=2*tauE;
Te=Ti;
sgmv1=fsgmvdt(Ti); Y1=17.59*1e6*qe; Y1p=3.52*1e6*qe; Y1n=14.07*1e6*qe;
sgmv2=fsgmvdd2(Ti); Y2=3.27*1e6*qe; Y2p=0.82*1e6*qe; Y2n=2.45*1e6*qe;
sgmv3=fsgmvdd1(Ti); Y3=4.04*1e6*qe; Y3p=4.04*1e6*qe; Y3n=0.0*1e6*qe;
sgmv4=fsgmvdhe(Ti); Y4=18.35*1e6*qe; Y4p=18.35*1e6*qe; Y4n=0.0*1e6*qe;

options=optimoptions('fsolve','Display','none','MaxIter',1000,...
    'MaxFunEvals',1000,'TolX',1e-8,'TolFun',1e-8);
x=fsolve(@fdfuelden,x0,options);
% 
% nj=exp(x(1:5))
% Sj=exp(x(6))

nd=exp(x(1)); nt=exp(x(2)); nh=exp(x(3)); 
% nd=x(1); nt=x(2); nh=x(3);

np=(0.5*nd.^2*sgmv3+nd.*nh*sgmv4)*tauN;
na=(nd.*nt*sgmv1+nd.*nh*sgmv4)*tauN;
% np+nd+nt+nh*Zh+na*Za
% (-nd.*nt*sgmv1+0.5*nd.^2*sgmv3-nt/tauN)
% (0.5*nd.^2*sgmv2-nd.*nh*sgmv4-nh/tauN)

% ne=np+nd+nt+nh*Zh+na*Za;
ni=np+nd+nt+nh+na;
% Zi=ne/ni;
Zeff=(np+nd+nt+nh*Zh^2+na*Za^2)/ne;


%%
Pfus=nd*nt*sgmv1*Y1+0.5*nd*nd*(sgmv2*Y2+sgmv3*Y3)+nd*nh*sgmv4*Y4; % W/m^-3
Pfusp=nd*nt*sgmv1*Y1p+0.5*nd*nd*(sgmv2*Y2p+sgmv3*Y3p)+nd*nh*sgmv4*Y4p; % W/m^-3
Pfusn=nd*nt*sgmv1*Y1n+0.5*nd*nd*sgmv2*Y2n; % W/m^-3

mec2=511; % keV
Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*(Zeff*(1+0.7936*(Te./mec2)+...
    1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2))*1e6; % W/m^3

Rw=0.8;
a=1.0; % m, default minor radius
% Pcycl=4.14e-7*(ne/1e20)^0.5*Te.^2.5*B^2.5*(1-Rw)^0.5*(1+...
%     2.5*Te/511)/sqrt(a)*1e6; % W/m^3
Pcycl=4.14e-7*(ne/1e20)^0.5*(Te/2).^2.5*B^2.5*(1-Rw)^0.5*(1+...
    2.5*Te/511)/sqrt(a)*1e6; % W/m^3 22-04-22 11:00 use Teff=Te/2, Kukushkin09

beta=2*mu0*(ni*Ti+ne*Te)*1e3*qe/B^2;

Eth=1.5*(ni*Ti+ne*Te)*1e3*qe; % J/m^3

Pth=Eth/tauE;

Pheat=Pcycl+Pbrem+Pth-Pfusp;
Qfus=Pfus/Pheat; % Pfus/Pheat

fpar(1)=log(Qfus)-log(Qfus0);
fpar(2)=beta-beta0;
fpar(3)=log(Pfus)-log(Pfus0);


end
