% 2022-04-21 11:50, Hua-sheng XIE, huashengxie@gmail.com
% Solve the density of p, D, T, He3, He4 for D-fuels
% Reduced the model to three density equations and use fsolve.

function fx=fdfuelden(x)

global ne sgmv1 sgmv2 sgmv3 sgmv4 tauE icase;

% nd=x(1); nt=x(2); nh=x(3);

nd=exp(x(1)); nt=exp(x(2)); nh=exp(x(3));

Zh=2; Za=2;

tauN=2*tauE;
% Sp=0; Sa=0;
if(icase==1) % D-T
    Sh=0;
    St=-(-nd.*nd*sgmv1+0.5*nd.^2*sgmv3-nd/tauN); %nd=nt;
elseif(icase==2) % D-He3
    St=0;
    Sh=-(0.5*nd.^2*sgmv2-nd.*nd*sgmv4-nd/tauN);
elseif(icase==3) % D-D-He3
    St=0;
    Sh=nh/tauN;
elseif(icase==4) % D-D-He3-T
    Sh=nh/tauN;
    St=nt/tauN;
elseif(icase==5) % D-D-T
    Sh=0;
    St=nt/tauN;
elseif(icase==6) % D-D
    Sh=0;
    St=0;
end


% 0=(0.5*nd.^2*sgmv3+nd.*nh*sgmv4-np/tauN)/ne;
% 0=(Sd-nd.*nt*sgmv1-nd.^2*sgmv2-nd.^2*sgmv3-nd.*nh*sgmv4-nd/tauN)/ne;
% 0=(nd.*nt*sgmv1+nd.*nh*sgmv4-na/tauN)/ne;
np=(0.5*nd.^2*sgmv3+nd.*nh*sgmv4)*tauN;
na=(nd.*nt*sgmv1+nd.*nh*sgmv4)*tauN;
% Sd=-(-nd.*nt*sgmv1-nd.^2*sgmv2-nd.^2*sgmv3-nd.*nh*sgmv4-nd/tauN);

fx(1)=(St-nd.*nt*sgmv1+0.5*nd.^2*sgmv3-nt/tauN)/ne;
fx(2)=(Sh+0.5*nd.^2*sgmv2-nd.*nh*sgmv4-nh/tauN)/ne;

fx(3)=(np+nd+nt+nh*Zh+na*Za-ne)/ne;

end