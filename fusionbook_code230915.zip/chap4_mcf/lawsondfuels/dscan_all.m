% 2022-04-21 10:58, Hua-sheng XIE, huashengxie@gmail.com
% plot n*tauE vs Q for Lawson diagram of D-fuels
% 22-04-22 14?28 scan (ne, Ti), seems ok
% 15:48 scan all icase
close all;clear;clc;

global ne sgmv1 sgmv2 sgmv3 sgmv4 tauE icase;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
% me=9.1094e-31; % kg
mp=1.6726e-27; % kg
% epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

md=2*mp; mt=3*mp; mh=3*mp; ma=4*mp;

% Ti=1:1.0:1000.0; % keV
% Ti=10.^(-0.0:0.0002:3.0); % keV

% icase=3;
% if(icase==1)
%     Ti=14; ne=2.6e20; tauE=0.9; B=2.4;
% elseif(icase==2)
%     Ti=70; ne=5.9e20; tauE=2.9; B=7.4;
% elseif(icase==3)
%     Ti=70; ne=5.9e20; tauE=4.7; B=7.9;
% elseif(icase==4)
%     Ti=70; ne=5.8e20; tauE=4.7; B=7.8;
% elseif(icase==5)
%     Ti=70; ne=6.7e20; tauE=8.2; B=8.4;
% elseif(icase==6)
%     Ti=70; ne=6.8e20; tauE=8.2; B=8.5;
% end

figure('unit','normalized','DefaultAxesFontSize',12,...
    'DefaultAxesLineWidth',1,...
    'position',[0.01,0.05,0.5,0.9]);

% tauE=10; B=10; 
Rw=0.8;

icasestr={'D-T','D-{}^3He','D-D-{}^3He','D-D-{}^3He-T','D-D-T','D-D'};

for icase=1:6
    icase
    
    if(icase==1)
        tauE=1.0; B=5.0;
        [nn,TT]=ndgrid(10.^(19:0.05:21),4:0.5:30);
    else
        [nn,TT]=ndgrid(10.^(20:0.05:22),5:1:100);
        tauE=10.0; B=10.0;
    end
    [nj1,nj2]=size(nn);
    
    ff=zeros(15,nj1,nj2);
    ff(1,:,:)=nn;
    ff(2,:,:)=TT;
    
    for j1=1:nj1
        j1
        for j2=1:nj2
            Ti=TT(j1,j2);
            ne=nn(j1,j2);
            
            x0=log([0.95, 0.01, 0.001]*ne);
            % x0=([0.95, 0.01, 0.001]*ne);
            
            Zh=2; Za=2; tauN=2*tauE;
            Te=Ti;
            sgmv1=fsgmvdt(Ti); Y1=17.59*1e6*qe; Y1p=3.52*1e6*qe; Y1n=14.07*1e6*qe;
            sgmv2=fsgmvdd2(Ti); Y2=3.27*1e6*qe; Y2p=0.82*1e6*qe; Y2n=2.45*1e6*qe;
            sgmv3=fsgmvdd1(Ti); Y3=4.04*1e6*qe; Y3p=4.04*1e6*qe; Y3n=0.0*1e6*qe;
            sgmv4=fsgmvdhe(Ti); Y4=18.35*1e6*qe; Y4p=18.35*1e6*qe; Y4n=0.0*1e6*qe;
            
            options=optimoptions('fsolve','Display','none','MaxIter',1000,...
                'MaxFunEvals',1000,'TolX',1e-12,'TolFun',1e-12);
            x=fsolve(@fdfuelden,x0,options);
            %
            % nj=exp(x(1:5))
            % Sj=exp(x(6))
            
            nd=exp(x(1)); nt=exp(x(2)); nh=exp(x(3));
            % nd=x(1); nt=x(2); nh=x(3);
            
            np=(0.5*nd.^2*sgmv3+nd.*nh*sgmv4)*tauN;
            na=(nd.*nt*sgmv1+nd.*nh*sgmv4)*tauN;
            % np+nd+nt+nh*Zh+na*Za
            % (-nd.*nt*sgmv1+0.5*nd.^2*sgmv3-nt/tauN)
            % (0.5*nd.^2*sgmv2-nd.*nh*sgmv4-nh/tauN)
            
            % ne=np+nd+nt+nh*Zh+na*Za;
            ni=np+nd+nt+nh+na;
            Zi=ne/ni;
            Zeff=(np+nd+nt+nh*Zh^2+na*Za^2)/ne;
            %         [nd,nh,nt,np,na]/ni
            Sd=-(-nd.*nt*sgmv1-nd.^2*sgmv2-nd.^2*sgmv3-nd.*nh*sgmv4-nd/tauN);
            St=-(-nd.*nt*sgmv1+0.5*nd.^2*sgmv3-nt/tauN);
            Sh=-(0.5*nd.^2*sgmv2-nd.*nh*sgmv4-nh/tauN);
            
            %%
            Pfus=nd*nt*sgmv1*Y1+0.5*nd*nd*(sgmv2*Y2+sgmv3*Y3)+nd*nh*sgmv4*Y4; % W/m^-3
            Pfusp=nd*nt*sgmv1*Y1p+0.5*nd*nd*(sgmv2*Y2p+sgmv3*Y3p)+nd*nh*sgmv4*Y4p; % W/m^-3
            Pfusn=nd*nt*sgmv1*Y1n+0.5*nd*nd*sgmv2*Y2n; % W/m^-3
            
            mec2=511; % keV
            Pbrem=1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*(Zeff*(1+0.7936*(Te./mec2)+...
                1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2))*1e6; % W/m^3
            
            a=1.0; % m, default minor radius
            % Pcycl=4.14e-7*(ne/1e20)^0.5*Te.^2.5*B^2.5*(1-Rw)^0.5*(1+...
            %     2.5*Te/511)/sqrt(a)*1e6; % W/m^3
            Pcycl=4.14e-7*(ne/1e20)^0.5*(Te/2).^2.5*B^2.5*(1-Rw)^0.5*(1+...
                2.5*Te/511)/sqrt(a)*1e6; % W/m^3 22-04-22 11:00 use Teff=Te/2, Kukushkin09
            
            beta=2*mu0*(ni*Ti+ne*Te)*1e3*qe/B^2;
            
            Eth=1.5*(ni*Ti+ne*Te)*1e3*qe; % J/m^3
            
            Pth=Eth/tauE;
            
            Pheat=Pcycl+Pbrem+Pth-Pfusp;
            Qfus=Pfus/Pheat; % Pfus/Pheat
            
            if(Qfus<=0 || Qfus>1000)
                Qfus=1000; % set max Qfus, 21-12-16 18:45
            end
            
            %         Pfusn/Pfus
            %         (Pbrem+Pcycl)/Pfus
            
            ff(3,j1,j2)=beta;
            ff(4,j1,j2)=Qfus;
            ff(5,j1,j2)=Pfus;
            ff(6,j1,j2)=Pfusp;
            ff(7,j1,j2)=Pfusn;
            ff(8,j1,j2)=Pbrem;
            ff(9,j1,j2)=Pcycl;
            ff(10,j1,j2)=np;
            ff(11,j1,j2)=nd;
            ff(12,j1,j2)=nt;
            ff(13,j1,j2)=nh;
            ff(14,j1,j2)=na;
            
        end
    end
    
    if(icase==1)
        ax1=axes('position',[0.1,0.71,0.4,0.25]);
    elseif(icase==2)
        ax2=axes('position',[0.1,0.39,0.4,0.25]);
    elseif(icase==3)
        ax3=axes('position',[0.1,0.07,0.4,0.25]);
    elseif(icase==4)
        ax4=axes('position',[0.56,0.71,0.4,0.25]);
    elseif(icase==5)
        ax5=axes('position',[0.56,0.39,0.4,0.25]);
    elseif(icase==6)
        ax6=axes('position',[0.56,0.07,0.4,0.25]);
        
    end
    
    
    contour(TT,nn,real(squeeze(ff(4,:,:))),[0.1,1,5,10,100],...
        'linewidth',2,'showtext','on','Color','b');hold on; % Qfus
    
    [CPfus,~]=contour(TT,nn,squeeze(ff(5,:,:))/1e6,[0.1,1,10,100],...
        'linewidth',2,'showtext','on','Color','g');hold on; % Pfus
    
    contour(TT,nn,real(squeeze(ff(3,:,:))),[0.01,0.1,0.5,1],...
        'linewidth',2,'showtext','on','Color','r','linestyle','--');hold on; % beta
    
%     text(1.2*min(min(TT)),1.2*min(min(nn)),icasestr(icase));
    
    % set(gca,'xscale','log');
    set(gca,'yscale','log');
    
    if(icase==1)
        leg1=legend('Q_{fus}','P_{fus}[MW/m^{-3}]','\beta');
        % legend('boxoff');
        set(leg1,'FontSize',8);
        
        % title(['icase=',num2str(icase),', B=',num2str(B,3),...
        %     'T, \tau_E=',num2str(tauE),'s, R_w=',num2str(Rw)]);
    end
    title([icasestr{icase}, ', B=',num2str(B,3),...
        'T, \tau_E=',num2str(tauE),'s, R_w=',num2str(Rw)]);
    
    if(icase==3 || icase==6)
        xlabel('T_i [keV]');
    end
    if(icase==1 || icase==2 || icase==3)
        ylabel('n_e [m^{-3}]');
    end
    
end

% save figure
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);

prtstr=['dscan2d_all_icase=',num2str(icase),...
    ',B=',num2str(B,3),...
    ',tauE=',num2str(tauE),...
    ',Rw=',num2str(Rw)];
print(gcf,'-dpdf',[prtstr,'.pdf']);

