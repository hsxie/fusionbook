% 2022-04-23 19:23, Hua-sheng XIE, huashengxie@gmail.com
% MCF p-B11 fusion model, with n_alpha and P_ei

close all; clear; clc;

% constants
kB=1.3807e-23; % J/K
qe=1.6022e-19; % C
me=9.1094e-31; % kg
mp=1.6726e-27; % kg
epsilon0=8.8542e-12; % F/m
mu0=4e-7*pi; % H/m
% c=2.99792458e8; % m/s

% inputs
tauE=20; % s
tauNaotauE=0.5;
npb=0.5e21; xpb=0.9;
Rw=0.95;
B=10; % T
tauEe=tauE;
tauEi=tauE;

x1=xpb; x2=(1-x1);
np=x1*npb; nb=x2*npb;

Z1=1.0; Z2=5.0; Z3=2;
m1=mp; m2=11*mp; m3=4*mp;
tauNa=tauNaotauE*tauE;

Ypb=8.68*1e6*qe; % MeV -> J
lnLmd=17;
ceff=3*(2*pi)^(1.5)*epsilon0^2*sqrt(me)/qe^4*(1e-3/qe)^(-1.5);

% Te=100:1:300;
Tii=50:5:500;
Tee=0.*Tii;
ff=zeros(15,length(Tii));
ff(1,:)=Tii;
for jT=1:length(Tii)
    Ti=Tii(jT);% keV
    
    % kBTe=TekeV*1e3*qe
    sgmvpb=fsgmv(Ti,5);
    na=3*np*nb*sgmvpb*tauNa;
    ne=Z1*np+Z2*nb+Z3*na;
    ni=np+nb+na;
    Zi=ne/ni;
    Zeff=(np*Z1^2+nb*Z2^2+na*Z3^2)/ne;
    
    mec2=511; % keV
    fPbrem=@(Te)1.69e-32*(ne*1e-6)^2.*sqrt(1e3*Te).*(Zeff*(1+0.7936*(Te./mec2)+...
        1.874*(Te./mec2).^2)+3/sqrt(2)*(Te./mec2))*1e6; % W/m^3
    
    a=1.0; % m, default minor radius
    fPcycl=@(Te)4.14e-7*(ne/1e20)^0.5*(Te/2).^2.5*B^2.5*(1-Rw)^0.5*(1+...
        2.5*Te/511)/sqrt(a)*1e6; % W/m^3 22-04-22 11:00 use Teff=Te/2, Kukushkin09
    
    fPthe=@(Te) 1.5*(ne*Te)*1e3*qe/tauEe; % J/m^3
    
    % to check
    fTe=@(Te)1.5*1e3*qe*((np*Z1)^2/m1+(nb*Z2)^2/m2+...
        (na*Z3)^2/m3)/(1/(2*me)*ceff/lnLmd)*(Ti-Te).*Te.^(-1.5)-...
        fPthe(Te)-fPcycl(Te)-fPbrem(Te);
    
    %     fTe=@(Te)1.5*1e3*qe*((x1*Z1)^2/m1+...
    %         (x2*Z2)^2/m2)/(1/(2*me)*ceff/lnLmd)*(Ti-Te).*Te.^(-1.5)-...
    %         fion*(x1*x2*sgmvpb)/(1+delta12)*Ypb/Zeff;
%     fTe=@(Te)1.5*1e3*qe*((x1*Z1)^2/m1+...
%         (x2*Z2)^2/m2)/(1/(2*me)*ceff/lnLmd)*(Ti-Te).*Te.^(-1.5)./...
%         ((x1*x2*sgmvpb)*Ypb/Zeff)-1;
    options=optimoptions('fsolve','Display','off');
    Te=fsolve(fTe,0.8*Ti,options);
    Tee(jT)=Te;
    
    beta=2*mu0*(ni*Ti+ne*Te)*1e3*qe/B^2;
    
    Eth=1.5*(ni*Ti+ne*Te)*1e3*qe; % J/m^3
    
    Pth=Eth/tauE;
    Pfus=(np*nb*sgmvpb)*Ypb;
    Pcycl=fPcycl(Te);
    Pbrem=fPbrem(Te);
    
    Pheat=Pcycl+Pbrem+Pth-Pfus;
    Qfus=Pfus/Pheat; % Pfus/Pheat
    
    if(Qfus<=0 || Qfus>1000)
        Qfus=1000; % set max Qfus, 21-12-16 18:45
    end

    ff(2,jT)=ne;
    ff(3,jT)=Te;
    ff(4,jT)=Qfus;
    ff(5,jT)=beta;
    ff(6,jT)=na/ni;
    ff(7,jT)=Pfus;
    ff(8,jT)=Pbrem;
    ff(9,jT)=Pcycl;
    ff(10,jT)=Pth;
    ff(11,jT)=Pheat;
    ff(12,jT)=Eth;
end
%% plot
close all;

figure('unit','normalized','DefaultAxesFontSize',12,...
    'DefaultAxesLineWidth',2,...
    'position',[0.01,0.05,0.65,0.85]);

fstr={'T_i [keV]','n_e [m^{-3}]','T_e [keV]','Q_{fus}','\beta',...
    'n_\alpha/n_i','P_{fus} [W/m^3]','P_{brem} [W/m^3]',...
    'P_{cycl} [W/m^3]','P_{th} [W/m^3]','P_{heat} [W/m^3]','E_{th} [J/m^3]'};

for jp=1:9
    subplot(3,3,jp);
plot(Tii,ff(jp+1,:),'linewidth',3);
xlabel('T_i [keV]');
ylabel(fstr{jp+1});
axis tight;
    
end
subplot(332);
title(['n_p/n_i=',num2str(xpb,3),', n_i=',num2str(ni,3),...
    'm^{-3}, \tau_E=',num2str(tauE),'s, B=',num2str(B),...
    'T, \tau_{N\alpha}/\tau_E=',num2str(tauNaotauE),...
    ', R_w=',num2str(Rw)]);
    
% ax1=axes('position',[0.1,0.12,0.84,0.81]);
% subplot(331);
% plot(Tii,Tee,'linewidth',3);
% subplot(332);
% plot(Tii,ff(3,:),'linewidth',3);
% subplot(333);
% plot(Tii,ff(4,:),'linewidth',3);
% subplot(334);
% plot(Tii,ff(5,:),'linewidth',3);
% subplot(335);
% plot(Tii,ff(6,:),'linewidth',3);
% subplot(336);
% plot(Tii,ff(7,:),'linewidth',3);
% subplot(337);
% plot(Tii,ff(8,:),'linewidth',3);
% 
% 
% xlabel('T_i [keV]');

prtstr=['mcfpb_xpb=',num2str(xpb,3),',ni=',num2str(ni,3),...
    ',tauE=',num2str(tauE),',B=',num2str(B),',tauNaotauE=',num2str(tauNaotauE),...
    ',Rw=',num2str(Rw)];

% save figure
set(gcf,'Units','inches');
screenposition = get(gcf,'Position');
set(gcf,'PaperPositionMode','Auto','PaperUnits',...
    'Inches','PaperSize',[screenposition(3:4)]);
% set(gcf,'PaperPosition',[0 0 screenposition(3:4)],...
%     'PaperSize',[screenposition(3:4)]);

% tauE=10; % s
% tauNaotauE=0.1;
% npb=1e21; xpb=0.9;
% Rw=1.0;
% B=10; % T

print(gcf,'-dpdf',[prtstr,'.pdf']);

